import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

const now = () => new Date();

export const adminUsers = pgTable("admin_users", {
  email: text("email").primaryKey(),
  role: text("role").notNull().default("admin"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const adminAssets = pgTable(
  "admin_assets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    objectPath: text("object_path").notNull().unique(),
    contentType: text("content_type").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    kind: text("kind").notNull(),
    uploadedBy: text("uploaded_by").notNull(),
    uploadedAt: timestamp("uploaded_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("admin_assets_kind_idx").on(table.kind)],
);

export const pendingAssetUploads = pgTable(
  "pending_asset_uploads",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    objectPath: text("object_path").notNull().unique(),
    contentType: text("content_type").notNull(),
    expectedSizeBytes: integer("expected_size_bytes").notNull(),
    kind: text("kind").notNull(),
    requestedBy: text("requested_by").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (table) => [index("pending_asset_uploads_expiry_idx").on(table.expiresAt)],
);

export const gifts = pgTable(
  "admin_gifts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    category: text("category").notNull(),
    price: integer("price").notNull().default(0),
    status: text("status").notNull().default("draft"),
    thumbnailAssetId: uuid("thumbnail_asset_id").references(() => adminAssets.id, {
      onDelete: "set null",
    }),
    imageAssetId: uuid("image_asset_id").references(() => adminAssets.id, {
      onDelete: "set null",
    }),
    modelAssetId: uuid("model_asset_id").references(() => adminAssets.id, {
      onDelete: "set null",
    }),
    soundAssetId: uuid("sound_asset_id").references(() => adminAssets.id, {
      onDelete: "set null",
    }),
    animationType: text("animation_type").notNull().default("float"),
    animationDurationMs: integer("animation_duration_ms").notNull().default(1400),
    displayOrder: integer("display_order").notNull().default(0),
    effectConfig: jsonb("effect_config").$type<Record<string, unknown>>().notNull().default({}),
    createdBy: text("created_by").notNull(),
    updatedBy: text("updated_by").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("admin_gifts_status_idx").on(table.status),
    index("admin_gifts_category_idx").on(table.category),
    index("admin_gifts_display_order_idx").on(table.displayOrder),
  ],
);

export const profileFrames = pgTable(
  "profile_frames",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    category: text("category").notNull(),
    status: text("status").notNull().default("draft"),
    assetId: uuid("asset_id").references(() => adminAssets.id, { onDelete: "set null" }),
    vipLevelRequired: text("vip_level_required"),
    unlockCondition: text("unlock_condition"),
    effects: jsonb("effects").$type<Record<string, unknown>>().notNull().default({}),
    createdBy: text("created_by").notNull(),
    updatedBy: text("updated_by").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("profile_frames_status_idx").on(table.status)],
);

export const vipLevels = pgTable(
  "vip_levels",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    level: integer("level").notNull(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    badgeAssetId: uuid("badge_asset_id").references(() => adminAssets.id, {
      onDelete: "set null",
    }),
    membershipDescription: text("membership_description").notNull().default(""),
    unlockCondition: text("unlock_condition").notNull().default(""),
    isActive: boolean("is_active").notNull().default(true),
    displayOrder: integer("display_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("vip_levels_level_unique_idx").on(table.level)],
);

export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").$type<Record<string, unknown>>().notNull(),
  updatedBy: text("updated_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().default(now()),
});

export const adminAuditLogs = pgTable(
  "admin_audit_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    actorId: text("actor_id").notNull(),
    actorEmail: text("actor_email").notNull(),
    action: text("action").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    details: jsonb("details").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("admin_audit_logs_created_at_idx").on(table.createdAt)],
);

export type AdminUser = typeof adminUsers.$inferSelect;
export type AdminAsset = typeof adminAssets.$inferSelect;
export type GiftRecord = typeof gifts.$inferSelect;
export type ProfileFrameRecord = typeof profileFrames.$inferSelect;
export type VipLevelRecord = typeof vipLevels.$inferSelect;
export type AdminAuditLog = typeof adminAuditLogs.$inferSelect;
