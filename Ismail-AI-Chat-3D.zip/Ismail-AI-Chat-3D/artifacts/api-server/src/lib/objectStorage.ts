import { randomUUID } from "node:crypto";
import { Storage, type File } from "@google-cloud/storage";

const sidecarUrl = "http://127.0.0.1:1106";

export const objectStorageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${sidecarUrl}/token`,
    type: "external_account",
    credential_source: {
      url: `${sidecarUrl}/credential`,
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

function getPrivateRoot(): { bucket: string; prefix: string } {
  const raw = process.env.PRIVATE_OBJECT_DIR?.replace(/^\/+|\/+$/g, "");
  if (!raw) throw new Error("Object Storage is not configured: PRIVATE_OBJECT_DIR is missing.");
  const [bucket, ...prefixParts] = raw.split("/");
  if (!bucket) throw new Error("Object Storage private directory is invalid.");
  return { bucket, prefix: prefixParts.join("/") };
}

function getObjectName(objectPath: string): string {
  if (!objectPath.startsWith("/objects/uploads/")) {
    throw new Error("Invalid private asset path.");
  }
  const relative = objectPath.slice("/objects/".length);
  if (relative.includes("..") || relative.includes("\\")) {
    throw new Error("Invalid private asset path.");
  }
  const { prefix } = getPrivateRoot();
  return [prefix, relative].filter(Boolean).join("/");
}

export async function createUploadTicket(): Promise<{
  objectPath: string;
  uploadUrl: string;
}> {
  const objectPath = `/objects/uploads/${randomUUID()}`;
  const { bucket } = getPrivateRoot();
  const objectName = getObjectName(objectPath);
  const uploadUrl = await createSignedUrl(bucket, objectName, "PUT", 15 * 60);
  return { objectPath, uploadUrl };
}

export async function getPrivateFile(objectPath: string): Promise<File> {
  const { bucket } = getPrivateRoot();
  const file = objectStorageClient.bucket(bucket).file(getObjectName(objectPath));
  const [exists] = await file.exists();
  if (!exists) throw new Error("Uploaded object was not found.");
  return file;
}

export async function getPrivatePreviewUrl(objectPath: string): Promise<{
  url: string;
  expiresAt: Date;
}> {
  const { bucket } = getPrivateRoot();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
  return {
    url: await createSignedUrl(bucket, getObjectName(objectPath), "GET", 10 * 60),
    expiresAt,
  };
}

export async function deletePrivateObject(objectPath: string): Promise<void> {
  const file = await getPrivateFile(objectPath);
  await file.delete();
}

export function getPublicObjectFile(objectPath: string): File {
  const { bucket } = getPrivateRoot();
  return objectStorageClient.bucket(bucket).file(getObjectName(objectPath));
}

async function createSignedUrl(
  bucket: string,
  objectName: string,
  method: "GET" | "PUT",
  ttlSeconds: number,
): Promise<string> {
  const response = await fetch(`${sidecarUrl}/object-storage/signed-object-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      bucket_name: bucket,
      object_name: objectName,
      method,
      expires_at: new Date(Date.now() + ttlSeconds * 1000).toISOString(),
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) {
    throw new Error(`Object Storage URL signing failed with status ${response.status}.`);
  }
  const body = (await response.json()) as { signed_url?: string };
  if (!body.signed_url) throw new Error("Object Storage did not return a signed URL.");
  return body.signed_url;
}
