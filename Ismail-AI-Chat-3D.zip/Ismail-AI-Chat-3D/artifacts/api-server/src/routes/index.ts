import { Router, type IRouter } from "express";
import healthRouter from "./health";
import adminRouter, { AdminRouteError } from "./admin";
import adminAssetsRouter from "./adminAssets";
import publicCatalogRouter from "./publicCatalog";

const router: IRouter = Router();

router.use(healthRouter);
router.use(publicCatalogRouter);
router.use("/admin", adminRouter);
router.use("/admin", adminAssetsRouter);

export default router;
export { AdminRouteError };
