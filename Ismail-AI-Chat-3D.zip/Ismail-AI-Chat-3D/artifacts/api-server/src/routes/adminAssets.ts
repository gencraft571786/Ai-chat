import { basename } from "node:path";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { Router } from "express";
import { z } from "zod";
import {
  adminAssets,
  adminAuditLogs,
  appSettings,
  db,
  gifts,
  pendingAssetUploads,
  profileFrames,
  vipLevels,
} from "@workspace/db";
import { getAdminActor, requireAdmin } from "../middlewares/adminAuth";
import {
  createUploadTicket,
  deletePrivateObject,
  getPrivateFile,
  getPrivatePreviewUrl,
} from "../lib/objectStorage";

const router = Router();
const uploadRequestSchema = z.object({
  name: z.string().trim().min(1).max(255),
  sizeBytes: z.number().int().min(1),
  contentType: z.string().trim().min(1).max(120),
  kind: z.enum([
    "gift-image",
    "gift-thumbnail",
    "gift-model",
    "frame",
    "audio",
    "video",
    "banner",
    "vip-badge",
    "other",
  ]),
});
const completeSchema = z.object({ pendingUploadId: z.string().uuid() });

const mimeByExtension: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  mp4: "video/mp4",
  glb: "model/gltf-binary",
  gltf: "model/gltf+json",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  ogg: "audio/ogg",
  m4a: "audio/mp4",
};

function maxBytes(contentType: string, extension: string): number {
  if (contentType.startsWith("image/")) return 15 * 1024 * 1024;
  if (contentType === "video/mp4") return 100 * 1024 * 1024;
  if (contentType === "model/gltf-binary") return 60 * 1024 * 1024;
  if (contentType === "model/gltf+json") return 10 * 1024 * 1024;
  if (contentType.startsWith("audio/")) return 20 * 1024 * 1024;
  return extension === "gltf" ? 10 * 1024 * 1024 : 15 * 1024 * 1024;
}

function kindAccepts(kind: string, contentType: string): boolean {
  if (kind === "gift-model") {
    return contentType === "model/gltf-binary" || contentType === "model/gltf+json";
  }
  if (kind === "audio") return contentType.startsWith("audio/");
  if (kind === "video") return contentType === "video/mp4";
  if (kind === "other") return true;
  if (kind === "gift-image" || kind === "gift-thumbnail" || kind === "frame") {
    return contentType.startsWith("image/") || contentType === "video/mp4";
  }
  if (kind === "banner") return contentType.startsWith("image/") || contentType === "video/mp4";
  if (kind === "vip-badge") return contentType.startsWith("image/");
  return false;
}

async function verifyAssetBytes(
  file: Awaited<ReturnType<typeof getPrivateFile>>,
  contentType: string,
  extension: string,
  sizeBytes: number,
): Promise<void> {
  if (contentType === "model/gltf+json") {
    const [fullFile] = await file.download();
    let model: Record<string, unknown>;
    try {
      model = JSON.parse(fullFile.toString("utf8").replace(/^\uFEFF/, "")) as Record<
        string,
        unknown
      >;
    } catch {
      throw new Error("The glTF file is not valid JSON.");
    }
    const assetInfo = model.asset as { version?: string } | undefined;
    if (!assetInfo?.version) throw new Error("The glTF asset metadata is missing.");
    for (const key of ["buffers", "images"] as const) {
      const resources = model[key];
      if (!Array.isArray(resources)) continue;
      for (const item of resources) {
        const uri = (item as { uri?: unknown }).uri;
        if (typeof uri === "string" && !uri.startsWith("data:")) {
          throw new Error(
            "This glTF file refers to external files. Embed its textures and buffers, or upload a single GLB file.",
          );
        }
      }
    }
    return;
  }

  const [header] = await file.download({ start: 0, end: Math.min(sizeBytes - 1, 31) });
  const startsWith = (...bytes: number[]) => bytes.every((byte, index) => header[index] === byte);
  let valid = false;
  if (contentType === "image/png") {
    valid = startsWith(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a);
  } else if (contentType === "image/jpeg") {
    valid = startsWith(0xff, 0xd8, 0xff);
  } else if (contentType === "image/gif") {
    const signature = header.subarray(0, 6).toString("ascii");
    valid = signature === "GIF87a" || signature === "GIF89a";
  } else if (contentType === "image/webp") {
    valid =
      header.subarray(0, 4).toString("ascii") === "RIFF" &&
      header.subarray(8, 12).toString("ascii") === "WEBP";
  } else if (contentType === "video/mp4") {
    valid = header.subarray(4, 8).toString("ascii") === "ftyp";
  } else if (contentType === "model/gltf-binary") {
    valid = header.subarray(0, 4).toString("ascii") === "glTF";
  } else if (contentType === "audio/wav") {
    valid =
      header.subarray(0, 4).toString("ascii") === "RIFF" &&
      header.subarray(8, 12).toString("ascii") === "WAVE";
  } else if (contentType === "audio/ogg") {
    valid = header.subarray(0, 4).toString("ascii") === "OggS";
  } else if (contentType === "audio/mpeg") {
    valid =
      header.subarray(0, 3).toString("ascii") === "ID3" ||
      (header[0] === 0xff && (header[1] & 0xe0) === 0xe0);
  } else if (contentType === "audio/mp4") {
    valid = header.subarray(4, 8).toString("ascii") === "ftyp";
  }
  if (!valid) throw new Error(`The file content does not match the .${extension} format.`);
}

async function audit(
  req: Parameters<typeof getAdminActor>[0],
  action: string,
  assetId: string,
  details: Record<string, unknown> = {},
) {
  const actor = getAdminActor(req);
  await db.insert(adminAuditLogs).values({
    actorId: actor.userId,
    actorEmail: actor.email,
    action,
    entityType: "asset",
    entityId: assetId,
    details,
  });
}

router.use(requireAdmin);

router.get("/assets", async (req, res) => {
  const search = typeof req.query.search === "string" ? req.query.search.trim() : "";
  const kind = typeof req.query.kind === "string" ? req.query.kind.trim() : "";
  const filters = [];
  if (search) filters.push(ilike(adminAssets.name, `%${search}%`));
  if (kind) filters.push(eq(adminAssets.kind, kind));

  const [rows, giftRows, frameRows, vipRows] = await Promise.all([
    db
      .select()
      .from(adminAssets)
      .where(filters.length ? and(...filters) : undefined)
      .orderBy(desc(adminAssets.uploadedAt))
      .limit(300),
    db
      .select({
        thumbnail: gifts.thumbnailAssetId,
        image: gifts.imageAssetId,
        model: gifts.modelAssetId,
        sound: gifts.soundAssetId,
      })
      .from(gifts),
    db.select({ assetId: profileFrames.assetId }).from(profileFrames),
    db.select({ assetId: vipLevels.badgeAssetId }).from(vipLevels),
  ]);
  const references = new Map<string, number>();
  const addReference = (id: string | null) => {
    if (id) references.set(id, (references.get(id) ?? 0) + 1);
  };
  for (const row of giftRows) {
    addReference(row.thumbnail);
    addReference(row.image);
    addReference(row.model);
    addReference(row.sound);
  }
  for (const row of frameRows) addReference(row.assetId);
  for (const row of vipRows) addReference(row.assetId);

  res.json(
    rows.map((row) => ({
      id: row.id,
      name: row.name,
      contentType: row.contentType,
      sizeBytes: row.sizeBytes,
      kind: row.kind,
      uploadedAt: row.uploadedAt.toISOString(),
      referenceCount: references.get(row.id) ?? 0,
      previewUrl: null,
    })),
  );
});

router.post("/uploads/request-url", async (req, res) => {
  const parsed = uploadRequestSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Invalid upload details." });
    return;
  }
  const extension = basename(parsed.data.name.replace(/\\/g, "/")).split(".").pop()?.toLowerCase();
  const expectedType = extension ? mimeByExtension[extension] : undefined;
  if (!extension || !expectedType || expectedType !== parsed.data.contentType) {
    res.status(400).json({ error: "This file extension and content type are not supported together." });
    return;
  }
  if (!kindAccepts(parsed.data.kind, expectedType)) {
    res.status(400).json({ error: "This file format is not supported for the selected asset type." });
    return;
  }
  if (parsed.data.sizeBytes > maxBytes(expectedType, extension)) {
    res.status(400).json({ error: "This file exceeds the size limit for its format." });
    return;
  }

  const safeName = basename(parsed.data.name.replace(/\\/g, "/")).replace(/[\u0000-\u001f]/g, "").trim();
  const { objectPath, uploadUrl } = await createUploadTicket();
  const actor = getAdminActor(req);
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  const [pending] = await db
    .insert(pendingAssetUploads)
    .values({
      name: safeName,
      objectPath,
      contentType: expectedType,
      expectedSizeBytes: parsed.data.sizeBytes,
      kind: parsed.data.kind,
      requestedBy: actor.userId,
      expiresAt,
    })
    .returning();
  res.status(201).json({
    pendingUploadId: pending.id,
    uploadUrl,
    objectPath,
    expiresAt: expiresAt.toISOString(),
  });
});

router.post("/uploads/complete", async (req, res) => {
  const parsed = completeSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid upload ticket." });
    return;
  }
  const actor = getAdminActor(req);
  const [pending] = await db
    .select()
    .from(pendingAssetUploads)
    .where(
      and(
        eq(pendingAssetUploads.id, parsed.data.pendingUploadId),
        eq(pendingAssetUploads.requestedBy, actor.userId),
      ),
    )
    .limit(1);
  if (!pending) {
    res.status(404).json({ error: "Upload ticket not found or already used." });
    return;
  }
  if (pending.expiresAt.getTime() < Date.now()) {
    await getPrivateFile(pending.objectPath)
      .then((file) => file.delete().catch(() => undefined))
      .catch(() => undefined);
    await db.delete(pendingAssetUploads).where(eq(pendingAssetUploads.id, pending.id));
    res.status(410).json({ error: "Upload ticket expired. Request a new one." });
    return;
  }

  try {
    const file = await getPrivateFile(pending.objectPath);
    const [objectMetadata] = await file.getMetadata();
    const actualSize = Number(objectMetadata.size);
    const actualType = String(objectMetadata.contentType ?? "").split(";")[0].trim().toLowerCase();
    const extension = pending.name.split(".").pop()?.toLowerCase() ?? "";
    if (!Number.isSafeInteger(actualSize) || actualSize !== pending.expectedSizeBytes) {
      throw new Error("Uploaded file size did not match the requested size.");
    }
    if (actualSize > maxBytes(pending.contentType, extension)) {
      throw new Error("Uploaded file exceeds the allowed size for this format.");
    }
    if (actualType !== pending.contentType) {
      throw new Error("Uploaded content type did not match the selected file format.");
    }
    await verifyAssetBytes(file, pending.contentType, extension, actualSize);
  } catch (error) {
    await getPrivateFile(pending.objectPath)
      .then((object) => object.delete().catch(() => undefined))
      .catch(() => undefined);
    await db.delete(pendingAssetUploads).where(eq(pendingAssetUploads.id, pending.id));
    res.status(400).json({
      error: error instanceof Error ? error.message : "Uploaded asset verification failed.",
    });
    return;
  }

  const [asset] = await db
    .insert(adminAssets)
    .values({
      name: pending.name,
      objectPath: pending.objectPath,
      contentType: pending.contentType,
      sizeBytes: pending.expectedSizeBytes,
      kind: pending.kind,
      uploadedBy: actor.userId,
    })
    .returning();
  await db.delete(pendingAssetUploads).where(eq(pendingAssetUploads.id, pending.id));
  await audit(req, "asset.uploaded", asset.id, {
    contentType: asset.contentType,
    sizeBytes: asset.sizeBytes,
    kind: asset.kind,
  });
  res.status(201).json({
    id: asset.id,
    name: asset.name,
    contentType: asset.contentType,
    sizeBytes: asset.sizeBytes,
    kind: asset.kind,
    uploadedAt: asset.uploadedAt.toISOString(),
    referenceCount: 0,
    previewUrl: null,
  });
});

router.get("/assets/:id/preview-url", async (req, res) => {
  const [asset] = await db
    .select()
    .from(adminAssets)
    .where(eq(adminAssets.id, req.params.id))
    .limit(1);
  if (!asset) {
    res.status(404).json({ error: "Asset not found." });
    return;
  }
  const preview = await getPrivatePreviewUrl(asset.objectPath);
  res.json({ url: preview.url, expiresAt: preview.expiresAt.toISOString() });
});

router.delete("/assets/:id", async (req, res) => {
  const [asset] = await db
    .select()
    .from(adminAssets)
    .where(eq(adminAssets.id, req.params.id))
    .limit(1);
  if (!asset) {
    res.status(404).json({ error: "Asset not found." });
    return;
  }
  const [giftUse, frameUse, vipUse, bannerUse] = await Promise.all([
    db
      .select({ id: gifts.id })
      .from(gifts)
      .where(
        or(
          eq(gifts.thumbnailAssetId, asset.id),
          eq(gifts.imageAssetId, asset.id),
          eq(gifts.modelAssetId, asset.id),
          eq(gifts.soundAssetId, asset.id),
        ),
      )
      .limit(1),
    db.select({ id: profileFrames.id }).from(profileFrames).where(eq(profileFrames.assetId, asset.id)).limit(1),
    db.select({ id: vipLevels.id }).from(vipLevels).where(eq(vipLevels.badgeAssetId, asset.id)).limit(1),
    db
      .select({ key: appSettings.key })
      .from(appSettings)
      .where(sql`${appSettings.value}->>'bannerAssetId' = ${asset.id}`)
      .limit(1),
  ]);
  if (giftUse[0] || frameUse[0] || vipUse[0] || bannerUse[0]) {
    res.status(409).json({ error: "This asset is referenced by catalog content or app settings." });
    return;
  }
  await deletePrivateObject(asset.objectPath);
  await db.delete(adminAssets).where(eq(adminAssets.id, asset.id));
  await audit(req, "asset.deleted", asset.id, { name: asset.name });
  res.status(204).end();
});

export default router;
