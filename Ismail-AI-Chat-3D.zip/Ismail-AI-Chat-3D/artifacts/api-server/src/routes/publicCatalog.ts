import { and, desc, eq, or, sql } from "drizzle-orm";
import { Router } from "express";
import { adminAssets, appSettings, db, gifts, profileFrames, vipLevels } from "@workspace/db";
import { getPrivateFile } from "../lib/objectStorage";
import { getCurrentSettings } from "./admin";

const router = Router();

router.get("/catalog", async (_req, res) => {
  const [giftRows, frameRows, vipRows, settings] = await Promise.all([
    db
      .select()
      .from(gifts)
      .where(eq(gifts.status, "published"))
      .orderBy(gifts.displayOrder, desc(gifts.createdAt))
      .limit(500),
    db
      .select()
      .from(profileFrames)
      .where(eq(profileFrames.status, "published"))
      .orderBy(desc(profileFrames.createdAt))
      .limit(300),
    db
      .select()
      .from(vipLevels)
      .where(eq(vipLevels.isActive, true))
      .orderBy(vipLevels.displayOrder, vipLevels.level)
      .limit(100),
    getCurrentSettings(),
  ]);

  res.json({
    gifts: giftRows.map((row) => ({
      id: row.id,
      name: row.name,
      description: row.description,
      category: row.category,
      price: row.price,
      status: row.status,
      thumbnailAssetId: row.thumbnailAssetId,
      imageAssetId: row.imageAssetId,
      modelAssetId: row.modelAssetId,
      soundAssetId: row.soundAssetId,
      thumbnailUrl: row.thumbnailAssetId
        ? `/api/catalog/assets/${row.thumbnailAssetId}/content`
        : row.imageAssetId
          ? `/api/catalog/assets/${row.imageAssetId}/content`
          : null,
      animationType: row.animationType,
      animationDurationMs: row.animationDurationMs,
      displayOrder: row.displayOrder,
      effectConfig: row.effectConfig ?? {},
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    })),
    frames: frameRows.map((row) => ({
      id: row.id,
      name: row.name,
      description: row.description,
      category: row.category,
      status: row.status,
      assetId: row.assetId,
      assetUrl: row.assetId ? `/api/catalog/assets/${row.assetId}/content` : null,
      vipLevelRequired: row.vipLevelRequired,
      unlockCondition: row.unlockCondition,
      effects: row.effects ?? {},
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    })),
    vipLevels: vipRows.map((row) => ({
      id: row.id,
      level: row.level,
      name: row.name,
      description: row.description,
      badgeAssetId: row.badgeAssetId,
      membershipDescription: row.membershipDescription,
      unlockCondition: row.unlockCondition,
      isActive: row.isActive,
      displayOrder: row.displayOrder,
      createdAt: row.createdAt.toISOString(),
    })),
    settings,
  });
});

router.get("/catalog/assets/:id/content", async (req, res) => {
  const assetId = req.params.id;
  const [asset] = await db
    .select()
    .from(adminAssets)
    .where(eq(adminAssets.id, assetId))
    .limit(1);
  if (!asset) {
    res.status(404).end();
    return;
  }

  const [giftUse, frameUse, vipUse, settingsUse] = await Promise.all([
    db
      .select({ id: gifts.id })
      .from(gifts)
      .where(
        and(
          eq(gifts.status, "published"),
          or(
            eq(gifts.thumbnailAssetId, asset.id),
            eq(gifts.imageAssetId, asset.id),
            eq(gifts.modelAssetId, asset.id),
            eq(gifts.soundAssetId, asset.id),
          ),
        ),
      )
      .limit(1),
    db
      .select({ id: profileFrames.id })
      .from(profileFrames)
      .where(and(eq(profileFrames.status, "published"), eq(profileFrames.assetId, asset.id)))
      .limit(1),
    db
      .select({ id: vipLevels.id })
      .from(vipLevels)
      .where(and(eq(vipLevels.isActive, true), eq(vipLevels.badgeAssetId, asset.id)))
      .limit(1),
    db
      .select({ key: appSettings.key })
      .from(appSettings)
      .where(sql`${appSettings.value}->>'bannerAssetId' = ${asset.id}`)
      .limit(1),
  ]);
  if (!giftUse[0] && !frameUse[0] && !vipUse[0] && !settingsUse[0]) {
    res.status(404).end();
    return;
  }

  try {
    const file = await getPrivateFile(asset.objectPath);
    res.setHeader("Content-Type", asset.contentType);
    res.setHeader("Content-Length", String(asset.sizeBytes));
    res.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=60");
    res.setHeader("X-Content-Type-Options", "nosniff");
    const stream = file.createReadStream();
    stream.on("error", () => {
      if (!res.headersSent) res.status(502);
      res.end();
    });
    stream.pipe(res);
  } catch {
    res.status(404).end();
  }
});

export default router;
