import { clerkClient } from "@clerk/express";
import {
  adminAssets,
  adminAuditLogs,
  adminUsers,
  appSettings,
  db,
  gifts,
  profileFrames,
  vipLevels,
} from "@workspace/db";
import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";
import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { getAdminActor, requireAdmin } from "../middlewares/adminAuth";

const router = Router();
const statusSchema = z.enum(["draft", "published", "archived"]);
const effectSchema = z.record(z.unknown()).default({});
const uuidSchema = z.string().uuid();

const giftInputSchema = z.object({
  name: z.string().trim().min(1).max(100),
  description: z.string().max(1000).optional().default(""),
  category: z.string().trim().min(1).max(80),
  price: z.number().int().min(0).max(100_000_000),
  status: statusSchema.optional().default("draft"),
  thumbnailAssetId: uuidSchema.nullable().optional().default(null),
  imageAssetId: uuidSchema.nullable().optional().default(null),
  modelAssetId: uuidSchema.nullable().optional().default(null),
  soundAssetId: uuidSchema.nullable().optional().default(null),
  animationType: z.string().max(40).optional().default("float"),
  animationDurationMs: z.number().int().min(0).max(60_000).optional().default(1400),
  displayOrder: z.number().int().min(0).optional().default(0),
  effectConfig: effectSchema,
});
const giftUpdateSchema = giftInputSchema.partial();

const frameInputSchema = z.object({
  name: z.string().trim().min(1).max(100),
  description: z.string().max(1000).optional().default(""),
  category: z.string().trim().min(1).max(80),
  status: statusSchema.optional().default("draft"),
  assetId: uuidSchema.nullable().optional().default(null),
  vipLevelRequired: z.string().max(80).nullable().optional().default(null),
  unlockCondition: z.string().max(500).nullable().optional().default(null),
  effects: effectSchema,
});
const frameUpdateSchema = frameInputSchema.partial();

const vipInputSchema = z.object({
  level: z.number().int().min(1).max(100),
  name: z.string().trim().min(1).max(80),
  description: z.string().max(500).optional().default(""),
  badgeAssetId: uuidSchema.nullable().optional().default(null),
  membershipDescription: z.string().max(500).optional().default(""),
  unlockCondition: z.string().max(500).optional().default(""),
  isActive: z.boolean().optional().default(true),
  displayOrder: z.number().int().min(0).optional().default(0),
});
const vipUpdateSchema = vipInputSchema.partial();

const settingsInputSchema = z.object({
  theme: z
    .object({
      background: z.string().regex(/^#[0-9a-fA-F]{6}$/),
      surface: z.string().regex(/^#[0-9a-fA-F]{6}$/),
      primary: z.string().regex(/^#[0-9a-fA-F]{6}$/),
      secondary: z.string().regex(/^#[0-9a-fA-F]{6}$/),
      accent: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    })
    .optional(),
  catalogAppearance: z
    .object({
      layout: z.enum(["grid", "list"]),
      showPrices: z.boolean(),
      title: z.string().max(80),
    })
    .optional(),
  bannerText: z.string().max(240).optional(),
  bannerAssetId: uuidSchema.nullable().optional(),
  effectsEnabled: z.boolean().optional(),
});
const moderationSchema = z.object({ reason: z.string().trim().min(3).max(500) });

const defaultSettings = {
  theme: {
    background: "#080B16",
    surface: "#141A2A",
    primary: "#7958F5",
    secondary: "#288EFF",
    accent: "#D8B55A",
  },
  catalogAppearance: {
    layout: "grid" as const,
    showPrices: true,
    title: "Made to be sent",
  },
  bannerText: "",
  bannerAssetId: null as string | null,
  effectsEnabled: true,
  updatedAt: null as string | null,
};

class AdminRouteError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

function validateBody<T>(
  schema: z.ZodType<T>,
  body: unknown,
  res: Response,
): T | undefined {
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    res.status(400).json({
      error: parsed.error.issues[0]?.message ?? "The submitted data is invalid.",
    });
    return undefined;
  }
  return parsed.data;
}

function toGift(row: typeof gifts.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    category: row.category,
    price: row.price,
    status: row.status,
    thumbnailAssetId: row.thumbnailAssetId,
    imageAssetId: row.imageAssetId,
    modelAssetId: row.modelAssetId,
    soundAssetId: row.soundAssetId,
    thumbnailUrl: row.thumbnailAssetId
      ? `/api/catalog/assets/${row.thumbnailAssetId}/content`
      : null,
    animationType: row.animationType,
    animationDurationMs: row.animationDurationMs,
    displayOrder: row.displayOrder,
    effectConfig: row.effectConfig ?? {},
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function toFrame(row: typeof profileFrames.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    category: row.category,
    status: row.status,
    assetId: row.assetId,
    assetUrl: row.assetId ? `/api/catalog/assets/${row.assetId}/content` : null,
    vipLevelRequired: row.vipLevelRequired,
    unlockCondition: row.unlockCondition,
    effects: row.effects ?? {},
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function toVipLevel(row: typeof vipLevels.$inferSelect) {
  return {
    id: row.id,
    level: row.level,
    name: row.name,
    description: row.description,
    badgeAssetId: row.badgeAssetId,
    membershipDescription: row.membershipDescription,
    unlockCondition: row.unlockCondition,
    isActive: row.isActive,
    displayOrder: row.displayOrder,
    createdAt: row.createdAt.toISOString(),
  };
}

async function recordAudit(
  req: Request,
  action: string,
  entityType: string,
  entityId: string | null,
  details: Record<string, unknown> = {},
) {
  const actor = getAdminActor(req);
  await db.insert(adminAuditLogs).values({
    actorId: actor.userId,
    actorEmail: actor.email,
    action,
    entityType,
    entityId,
    details,
  });
}

async function requireAsset(
  assetId: string | null | undefined,
  acceptedTypes: (contentType: string) => boolean,
  label: string,
) {
  if (!assetId) return;
  const [asset] = await db
    .select({ contentType: adminAssets.contentType })
    .from(adminAssets)
    .where(eq(adminAssets.id, assetId))
    .limit(1);
  if (!asset) throw new AdminRouteError(400, `${label} was not found in the asset library.`);
  if (!acceptedTypes(asset.contentType)) {
    throw new AdminRouteError(400, `${label} has an incompatible file format.`);
  }
}

const imageType = (type: string) => type.startsWith("image/");
const modelType = (type: string) =>
  type === "model/gltf-binary" || type === "model/gltf+json";
const audioType = (type: string) => type.startsWith("audio/");
const visualType = (type: string) => imageType(type) || type === "video/mp4";

router.use(requireAdmin);

router.get("/me", (req, res) => {
  const actor = getAdminActor(req);
  res.json({ userId: actor.userId, email: actor.email, role: "admin" });
});

router.get("/overview", async (_req, res) => {
  const [userCount, giftCount, frameCount, assetTotals, recentAdminChanges] =
    await Promise.all([
      clerkClient.users.getCount().catch(() => null),
      db.select({ count: sql<number>`count(*)::int` }).from(gifts),
      db.select({ count: sql<number>`count(*)::int` }).from(profileFrames),
      db
        .select({ total: sql<number>`coalesce(sum(${adminAssets.sizeBytes}), 0)::bigint` })
        .from(adminAssets),
      db.select().from(adminAuditLogs).orderBy(desc(adminAuditLogs.createdAt)).limit(8),
    ]);
  res.json({
    registeredUsers: userCount,
    activeUsers: null,
    totalGifts: Number(giftCount[0]?.count ?? 0),
    totalFrames: Number(frameCount[0]?.count ?? 0),
    voiceRoomsTracked: false,
    voiceRooms: null,
    giftActivityTracked: false,
    recentGiftActivity: [],
    totalStorageBytes: Number(assetTotals[0]?.total ?? 0),
    recentAdminChanges: recentAdminChanges.map((entry) => ({
      id: entry.id,
      actorEmail: entry.actorEmail,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId,
      details: entry.details ?? {},
      createdAt: entry.createdAt.toISOString(),
    })),
  });
});

router.get("/gifts", async (req, res) => {
  const search = typeof req.query.search === "string" ? req.query.search.trim() : "";
  const category = typeof req.query.category === "string" ? req.query.category.trim() : "";
  const status = typeof req.query.status === "string" ? req.query.status : "";
  const filters = [];
  if (search) filters.push(ilike(gifts.name, `%${search}%`));
  if (category) filters.push(eq(gifts.category, category));
  if (statusSchema.safeParse(status).success) {
    filters.push(eq(gifts.status, status));
  } else if (status) {
    res.status(400).json({ error: "Unknown gift status." });
    return;
  }
  const rows = await db
    .select()
    .from(gifts)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(asc(gifts.displayOrder), desc(gifts.createdAt))
    .limit(300);
  res.json(rows.map(toGift));
});

router.post("/gifts", async (req, res) => {
  const input = validateBody(giftInputSchema, req.body, res);
  if (!input) return;
  if (input.status === "published" && !input.thumbnailAssetId && !input.imageAssetId) {
    res.status(400).json({ error: "Add a thumbnail or image before publishing this gift." });
    return;
  }
  await requireAsset(input.thumbnailAssetId, imageType, "Gift thumbnail");
  await requireAsset(input.imageAssetId, visualType, "Gift image");
  await requireAsset(input.modelAssetId, modelType, "3D model");
  await requireAsset(input.soundAssetId, audioType, "Sound effect");
  const actor = getAdminActor(req);
  const [row] = await db
    .insert(gifts)
    .values({ ...input, createdBy: actor.userId, updatedBy: actor.userId })
    .returning();
  await recordAudit(req, "gift.created", "gift", row.id, { name: row.name, status: row.status });
  res.status(201).json(toGift(row));
});

router.patch("/gifts/:id", async (req, res) => {
  if (!uuidSchema.safeParse(req.params.id).success) {
    res.status(400).json({ error: "Invalid gift identifier." });
    return;
  }
  const input = validateBody(giftUpdateSchema, req.body, res);
  if (!input) return;
  if (Object.keys(input).length === 0) {
    res.status(400).json({ error: "Provide at least one field to update." });
    return;
  }
  const [existing] = await db.select().from(gifts).where(eq(gifts.id, req.params.id)).limit(1);
  if (!existing) {
    res.status(404).json({ error: "Gift not found." });
    return;
  }
  const next = { ...existing, ...input };
  if (next.status === "published" && !next.thumbnailAssetId && !next.imageAssetId) {
    res.status(400).json({ error: "Add a thumbnail or image before publishing this gift." });
    return;
  }
  await requireAsset(next.thumbnailAssetId, imageType, "Gift thumbnail");
  await requireAsset(next.imageAssetId, visualType, "Gift image");
  await requireAsset(next.modelAssetId, modelType, "3D model");
  await requireAsset(next.soundAssetId, audioType, "Sound effect");
  const actor = getAdminActor(req);
  const [row] = await db
    .update(gifts)
    .set({ ...input, updatedBy: actor.userId, updatedAt: new Date() })
    .where(eq(gifts.id, req.params.id))
    .returning();
  await recordAudit(req, "gift.updated", "gift", row.id, {
    changedFields: Object.keys(input),
    status: row.status,
  });
  res.json(toGift(row));
});

router.delete("/gifts/:id", async (req, res) => {
  if (!uuidSchema.safeParse(req.params.id).success) {
    res.status(400).json({ error: "Invalid gift identifier." });
    return;
  }
  const [row] = await db.select().from(gifts).where(eq(gifts.id, req.params.id)).limit(1);
  if (!row) {
    res.status(404).json({ error: "Gift not found." });
    return;
  }
  if (row.status === "published") {
    res.status(409).json({ error: "Archive a published gift instead of deleting it." });
    return;
  }
  await db.delete(gifts).where(eq(gifts.id, row.id));
  await recordAudit(req, "gift.deleted", "gift", row.id, { name: row.name });
  res.status(204).end();
});

router.get("/frames", async (req, res) => {
  const search = typeof req.query.search === "string" ? req.query.search.trim() : "";
  const status = typeof req.query.status === "string" ? req.query.status : "";
  const filters = [];
  if (search) filters.push(ilike(profileFrames.name, `%${search}%`));
  if (statusSchema.safeParse(status).success) {
    filters.push(eq(profileFrames.status, status));
  } else if (status) {
    res.status(400).json({ error: "Unknown frame status." });
    return;
  }
  const rows = await db
    .select()
    .from(profileFrames)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(profileFrames.createdAt))
    .limit(300);
  res.json(rows.map(toFrame));
});

router.post("/frames", async (req, res) => {
  const input = validateBody(frameInputSchema, req.body, res);
  if (!input) return;
  if (input.status === "published" && !input.assetId) {
    res.status(400).json({ error: "Add a frame asset before publishing this frame." });
    return;
  }
  await requireAsset(input.assetId, visualType, "Frame");
  const actor = getAdminActor(req);
  const [row] = await db
    .insert(profileFrames)
    .values({ ...input, createdBy: actor.userId, updatedBy: actor.userId })
    .returning();
  await recordAudit(req, "frame.created", "profile_frame", row.id, {
    name: row.name,
    status: row.status,
  });
  res.status(201).json(toFrame(row));
});

router.patch("/frames/:id", async (req, res) => {
  if (!uuidSchema.safeParse(req.params.id).success) {
    res.status(400).json({ error: "Invalid frame identifier." });
    return;
  }
  const input = validateBody(frameUpdateSchema, req.body, res);
  if (!input) return;
  if (Object.keys(input).length === 0) {
    res.status(400).json({ error: "Provide at least one field to update." });
    return;
  }
  const [existing] = await db
    .select()
    .from(profileFrames)
    .where(eq(profileFrames.id, req.params.id))
    .limit(1);
  if (!existing) {
    res.status(404).json({ error: "Profile frame not found." });
    return;
  }
  const next = { ...existing, ...input };
  if (next.status === "published" && !next.assetId) {
    res.status(400).json({ error: "Add a frame asset before publishing this frame." });
    return;
  }
  await requireAsset(next.assetId, visualType, "Frame");
  const actor = getAdminActor(req);
  const [row] = await db
    .update(profileFrames)
    .set({ ...input, updatedBy: actor.userId, updatedAt: new Date() })
    .where(eq(profileFrames.id, req.params.id))
    .returning();
  await recordAudit(req, "frame.updated", "profile_frame", row.id, {
    changedFields: Object.keys(input),
    status: row.status,
  });
  res.json(toFrame(row));
});

router.delete("/frames/:id", async (req, res) => {
  if (!uuidSchema.safeParse(req.params.id).success) {
    res.status(400).json({ error: "Invalid frame identifier." });
    return;
  }
  const [row] = await db
    .select()
    .from(profileFrames)
    .where(eq(profileFrames.id, req.params.id))
    .limit(1);
  if (!row) {
    res.status(404).json({ error: "Profile frame not found." });
    return;
  }
  if (row.status === "published") {
    res.status(409).json({ error: "Archive a published frame instead of deleting it." });
    return;
  }
  await db.delete(profileFrames).where(eq(profileFrames.id, row.id));
  await recordAudit(req, "frame.deleted", "profile_frame", row.id, { name: row.name });
  res.status(204).end();
});

router.get("/vip-levels", async (_req, res) => {
  const rows = await db
    .select()
    .from(vipLevels)
    .orderBy(asc(vipLevels.displayOrder), asc(vipLevels.level))
    .limit(200);
  res.json(rows.map(toVipLevel));
});

router.post("/vip-levels", async (req, res) => {
  const input = validateBody(vipInputSchema, req.body, res);
  if (!input) return;
  await requireAsset(input.badgeAssetId, imageType, "VIP badge");
  const actor = getAdminActor(req);
  const [row] = await db.insert(vipLevels).values(input).returning();
  await recordAudit(req, "vip_level.created", "vip_level", row.id, {
    name: row.name,
    level: row.level,
    actorId: actor.userId,
  });
  res.status(201).json(toVipLevel(row));
});

router.patch("/vip-levels/:id", async (req, res) => {
  if (!uuidSchema.safeParse(req.params.id).success) {
    res.status(400).json({ error: "Invalid VIP level identifier." });
    return;
  }
  const input = validateBody(vipUpdateSchema, req.body, res);
  if (!input) return;
  if (Object.keys(input).length === 0) {
    res.status(400).json({ error: "Provide at least one field to update." });
    return;
  }
  const [existing] = await db.select().from(vipLevels).where(eq(vipLevels.id, req.params.id)).limit(1);
  if (!existing) {
    res.status(404).json({ error: "VIP level not found." });
    return;
  }
  await requireAsset(input.badgeAssetId ?? existing.badgeAssetId, imageType, "VIP badge");
  const [row] = await db
    .update(vipLevels)
    .set(input)
    .where(eq(vipLevels.id, existing.id))
    .returning();
  await recordAudit(req, "vip_level.updated", "vip_level", row.id, {
    changedFields: Object.keys(input),
  });
  res.json(toVipLevel(row));
});

router.delete("/vip-levels/:id", async (req, res) => {
  if (!uuidSchema.safeParse(req.params.id).success) {
    res.status(400).json({ error: "Invalid VIP level identifier." });
    return;
  }
  const [row] = await db.select().from(vipLevels).where(eq(vipLevels.id, req.params.id)).limit(1);
  if (!row) {
    res.status(404).json({ error: "VIP level not found." });
    return;
  }
  const [inUse] = await db
    .select({ id: profileFrames.id })
    .from(profileFrames)
    .where(eq(profileFrames.vipLevelRequired, row.name))
    .limit(1);
  if (inUse) {
    res.status(409).json({ error: "This VIP level is required by one or more profile frames." });
    return;
  }
  await db.delete(vipLevels).where(eq(vipLevels.id, row.id));
  await recordAudit(req, "vip_level.deleted", "vip_level", row.id, { name: row.name });
  res.status(204).end();
});

async function getCurrentSettings() {
  const [row] = await db.select().from(appSettings).where(eq(appSettings.key, "main")).limit(1);
  if (!row) return defaultSettings;
  const value = row.value as Partial<typeof defaultSettings>;
  return {
    ...defaultSettings,
    ...value,
    theme: { ...defaultSettings.theme, ...value.theme },
    catalogAppearance: {
      ...defaultSettings.catalogAppearance,
      ...value.catalogAppearance,
    },
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/settings", async (_req, res) => {
  res.json(await getCurrentSettings());
});

router.patch("/settings", async (req, res) => {
  const input = validateBody(settingsInputSchema, req.body, res);
  if (!input) return;
  if (Object.keys(input).length === 0) {
    res.status(400).json({ error: "Provide at least one setting to save." });
    return;
  }
  if (input.bannerAssetId) {
    await requireAsset(input.bannerAssetId, visualType, "App banner");
  }
  const current = await getCurrentSettings();
  const updatedAt = new Date();
  const next = {
    ...current,
    ...input,
    theme: { ...current.theme, ...input.theme },
    catalogAppearance: {
      ...current.catalogAppearance,
      ...input.catalogAppearance,
    },
    updatedAt: updatedAt.toISOString(),
  };
  const actor = getAdminActor(req);
  await db
    .insert(appSettings)
    .values({ key: "main", value: next, updatedBy: actor.userId, updatedAt })
    .onConflictDoUpdate({
      target: appSettings.key,
      set: { value: next, updatedBy: actor.userId, updatedAt },
    });
  await recordAudit(req, "app_settings.updated", "app_settings", "main", {
    changedFields: Object.keys(input),
  });
  res.json(next);
});

router.get("/users", async (req, res) => {
  const search = typeof req.query.search === "string" ? req.query.search.trim().slice(0, 100) : "";
  const result = await clerkClient.users.getUserList({
    limit: 100,
    ...(search ? { query: search } : {}),
  });
  res.json(
    result.data.map((user) => {
      const email =
        user.primaryEmailAddress?.emailAddress ??
        user.emailAddresses[0]?.emailAddress ??
        "";
      const fullName =
        [user.firstName, user.lastName].filter(Boolean).join(" ") ||
        user.username ||
        email;
      return {
        id: user.id,
        fullName,
        email,
        imageUrl: user.imageUrl || null,
        createdAt: new Date(user.createdAt).toISOString(),
        banned: user.banned,
      };
    }),
  );
});

async function moderateUser(req: Request, id: string, reason: string, banned: boolean) {
  const actor = getAdminActor(req);
  if (id === actor.userId) {
    throw new AdminRouteError(409, "Administrators cannot moderate their own account.");
  }
  const user = await clerkClient.users.getUser(id);
  const email = user.primaryEmailAddress?.emailAddress?.trim().toLowerCase();
  if (email) {
    const [isAdmin] = await db
      .select({ email: adminUsers.email })
      .from(adminUsers)
      .where(and(eq(adminUsers.email, email), eq(adminUsers.isActive, true)))
      .limit(1);
    if (isAdmin) throw new AdminRouteError(409, "Administrator accounts cannot be moderated here.");
  }
  const updated = banned
    ? await clerkClient.users.banUser(id)
    : await clerkClient.users.unbanUser(id);
  await recordAudit(req, banned ? "user.banned" : "user.unbanned", "user", id, {
    reason,
    email: email ?? null,
  });
  const userEmail =
    updated.primaryEmailAddress?.emailAddress ??
    updated.emailAddresses[0]?.emailAddress ??
    "";
  return {
    id: updated.id,
    fullName:
      [updated.firstName, updated.lastName].filter(Boolean).join(" ") ||
      updated.username ||
      userEmail,
    email: userEmail,
    imageUrl: updated.imageUrl || null,
    createdAt: new Date(updated.createdAt).toISOString(),
    banned: updated.banned,
  };
}

router.post("/users/:id/ban", async (req, res) => {
  const body = validateBody(moderationSchema, req.body, res);
  if (!body) return;
  res.json(await moderateUser(req, req.params.id, body.reason, true));
});

router.post("/users/:id/unban", async (req, res) => {
  res.json(await moderateUser(req, req.params.id, "Administrator restored account access.", false));
});

router.get("/rooms", (_req, res) => {
  res.json({
    tracked: false,
    message: "Voice room records are unavailable because this app has no connected room service.",
    rooms: [],
  });
});

router.get("/audit", async (_req, res) => {
  const rows = await db
    .select()
    .from(adminAuditLogs)
    .orderBy(desc(adminAuditLogs.createdAt))
    .limit(100);
  res.json(
    rows.map((row) => ({
      id: row.id,
      actorEmail: row.actorEmail,
      action: row.action,
      entityType: row.entityType,
      entityId: row.entityId,
      details: row.details ?? {},
      createdAt: row.createdAt.toISOString(),
    })),
  );
});

export { AdminRouteError, getCurrentSettings };
export default router;
