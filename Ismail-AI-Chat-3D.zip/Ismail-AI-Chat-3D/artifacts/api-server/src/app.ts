import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware } from "@clerk/express";
import router, { AdminRouteError } from "./routes";
import { logger } from "./lib/logger";
import {
  clerkProxyMiddleware,
  CLERK_PROXY_PATH,
} from "./middlewares/clerkProxyMiddleware";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use(clerkMiddleware());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

app.use(
  (
    error: unknown,
    req: express.Request,
    res: express.Response,
    next: express.NextFunction,
  ) => {
    if (res.headersSent) {
      next(error);
      return;
    }
    const status = error instanceof AdminRouteError ? error.status : 500;
    logger.error(
      { err: error, status, method: req.method, url: req.originalUrl.split("?")[0] },
      "API request failed",
    );
    res.status(status).json({
      error:
        status < 500 && error instanceof Error
          ? error.message
          : "The server could not complete this request.",
    });
  },
);

export default app;
