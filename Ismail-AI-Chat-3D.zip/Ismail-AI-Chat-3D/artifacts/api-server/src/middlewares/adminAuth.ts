import { clerkClient, getAuth } from "@clerk/express";
import { and, eq } from "drizzle-orm";
import type { NextFunction, Request, Response } from "express";
import { adminUsers, db } from "@workspace/db";
import { logger } from "../lib/logger";

export type AdminActor = {
  userId: string;
  email: string;
};

declare global {
  namespace Express {
    interface Request {
      adminActor?: AdminActor;
    }
  }
}

export async function requireAdmin(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to continue." });
    return;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const email = user.primaryEmailAddress?.emailAddress?.trim().toLowerCase();
    const verified = user.primaryEmailAddress?.verification?.status === "verified";
    if (!email || !verified) {
      res.status(403).json({ error: "A verified primary email is required for admin access." });
      return;
    }

    const initialAdminEmail = process.env.INITIAL_ADMIN_EMAIL?.trim().toLowerCase();
    if (initialAdminEmail && email === initialAdminEmail) {
      await db
        .insert(adminUsers)
        .values({ email: initialAdminEmail, role: "admin", isActive: true })
        .onConflictDoNothing();
    }

    const [admin] = await db
      .select({ email: adminUsers.email })
      .from(adminUsers)
      .where(and(eq(adminUsers.email, email), eq(adminUsers.isActive, true)))
      .limit(1);
    if (!admin) {
      res.status(403).json({ error: "This account is not an authorized administrator." });
      return;
    }

    req.adminActor = { userId, email };
    next();
  } catch (error) {
    logger.error({ err: error, userId }, "Admin authorization check failed");
    res.status(503).json({ error: "Administrator access could not be verified. Try again shortly." });
  }
}

export function getAdminActor(req: Request): AdminActor {
  if (!req.adminActor) throw new Error("Admin actor is missing after authorization.");
  return req.adminActor;
}
