import { RoomsScreen } from '@/screens/FeatureScreens';
export default RoomsScreen;
