import { ProfileScreen } from '@/screens/FeatureScreens';
export default ProfileScreen;
