import { GiftsScreen } from '@/screens/FeatureScreens';
export default GiftsScreen;
