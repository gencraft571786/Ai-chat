import { useSignIn } from "@clerk/expo";
import { Link, useRouter } from "expo-router";
import React, { useState } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from "react-native";
import { AdminButton, AdminCard, AdminField, AdminNotice, ADMIN_COLORS } from "@/components/admin/shared";

export default function AdminSignInScreen() {
  const { signIn, errors, fetchStatus } = useSignIn();
  const router = useRouter();
  const [emailAddress, setEmailAddress] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [mfaStep, setMfaStep] = useState(false);
  const [message, setMessage] = useState("");
  const busy = fetchStatus === "fetching";
  const errorMessage =
    errors.fields.identifier?.message ??
    errors.fields.password?.message ??
    errors.fields.code?.message ??
    message;

  const finishSignIn = async () => {
    await signIn.finalize({
      navigate: ({ session, decorateUrl }) => {
        if (session?.currentTask) {
          setMessage("Complete the required account task, then sign in again.");
          return;
        }
        const url = decorateUrl("/admin");
        if (Platform.OS === "web" && url.startsWith("http")) {
          window.location.href = url;
        } else {
          router.replace("/admin");
        }
      },
    });
  };

  const submitPassword = async () => {
    setMessage("");
    const result = await signIn.password({ emailAddress: emailAddress.trim(), password });
    if (result.error) {
      setMessage(result.error.message ?? "Sign-in failed. Check your details and try again.");
      return;
    }
    if (signIn.status === "complete") {
      await finishSignIn();
      return;
    }
    if (signIn.status === "needs_second_factor" || signIn.status === "needs_client_trust") {
      const emailFactor = signIn.supportedSecondFactors.find(
        (factor) => factor.strategy === "email_code",
      );
      if (emailFactor) {
        const sent = await signIn.mfa.sendEmailCode();
        if (sent.error) {
          setMessage(sent.error.message ?? "Could not send the verification code.");
          return;
        }
        setMfaStep(true);
      } else {
        setMessage("This account requires a second-factor method not supported on this screen.");
      }
    }
  };

  const verifyCode = async () => {
    setMessage("");
    const result = await signIn.mfa.verifyEmailCode({ code });
    if (result.error) {
      setMessage(result.error.message ?? "The verification code could not be confirmed.");
      return;
    }
    if (signIn.status === "complete") await finishSignIn();
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: ADMIN_COLORS.background }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: "center", padding: 22 }}>
        <View style={{ width: "100%", maxWidth: 500, alignSelf: "center", gap: 18 }}>
          <View style={{ gap: 8, paddingHorizontal: 4 }}>
            <Text style={{ color: ADMIN_COLORS.gold, fontSize: 11, fontWeight: "800", letterSpacing: 2 }}>
              ISMAIL AI CHAT
            </Text>
            <Text style={{ color: ADMIN_COLORS.text, fontSize: 30, fontWeight: "800" }}>
              Admin Control Center
            </Text>
            <Text style={{ color: ADMIN_COLORS.muted, fontSize: 14, lineHeight: 21 }}>
              Sign in with your administrator account. Admin access is checked by the server.
            </Text>
          </View>
          <AdminCard title={mfaStep ? "Verify sign-in" : "Secure sign-in"}>
            {mfaStep ? (
              <>
                <AdminNotice message="A verification code was sent to the account email." />
                <AdminField
                  label="Verification code"
                  value={code}
                  onChangeText={setCode}
                  placeholder="Enter the code"
                  keyboardType="number-pad"
                  autoCapitalize="none"
                />
                <AdminButton
                  label={busy ? "Verifying…" : "Verify and continue"}
                  onPress={() => void verifyCode()}
                  disabled={!code || busy}
                />
                <AdminButton
                  label="Use a different account"
                  kind="quiet"
                  onPress={() => {
                    setMfaStep(false);
                    setCode("");
                    signIn.reset();
                  }}
                />
              </>
            ) : (
              <>
                <AdminField
                  label="Email address"
                  value={emailAddress}
                  onChangeText={setEmailAddress}
                  placeholder="name@example.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoComplete="email"
                />
                <AdminField
                  label="Password"
                  value={password}
                  onChangeText={setPassword}
                  placeholder="Enter password"
                  secureTextEntry
                  autoComplete="current-password"
                  autoCapitalize="none"
                />
                <View style={{ gap: 12, marginTop: 4 }}>
                  {errorMessage ? <AdminNotice kind="error" message={errorMessage} /> : null}
                  <AdminButton
                    label={busy ? "Signing in…" : "Continue securely"}
                    icon="lock"
                    onPress={() => void submitPassword()}
                    disabled={!emailAddress || !password || busy}
                  />
                </View>
              </>
            )}
            <View nativeID="clerk-captcha" />
          </AdminCard>
          {!mfaStep ? (
            <Text style={{ color: ADMIN_COLORS.muted, textAlign: "center", fontSize: 13 }}>
              First administrator?{" "}
              <Link href="/admin/sign-up" style={{ color: ADMIN_COLORS.gold, fontWeight: "700" }}>
                Set up your verified account
              </Link>
            </Text>
          ) : null}
          <Link href="/" style={{ color: ADMIN_COLORS.muted, textAlign: "center", fontSize: 12 }}>
            Return to the app
          </Link>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
