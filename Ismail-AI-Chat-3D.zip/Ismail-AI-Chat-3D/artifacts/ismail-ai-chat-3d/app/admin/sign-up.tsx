import { useAuth, useSignUp } from "@clerk/expo";
import { Link, useRouter } from "expo-router";
import React, { useState } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from "react-native";
import { AdminButton, AdminCard, AdminField, AdminNotice, ADMIN_COLORS } from "@/components/admin/shared";

export default function AdminSignUpScreen() {
  const { signUp, errors, fetchStatus } = useSignUp();
  const { isSignedIn } = useAuth();
  const router = useRouter();
  const [emailAddress, setEmailAddress] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [codeSent, setCodeSent] = useState(false);
  const [message, setMessage] = useState("");
  const busy = fetchStatus === "fetching";
  const errorMessage =
    errors.fields.emailAddress?.message ??
    errors.fields.password?.message ??
    errors.fields.code?.message ??
    message;

  if (isSignedIn) {
    router.replace("/admin");
    return null;
  }

  const finishSignUp = async () => {
    await signUp.finalize({
      navigate: ({ session, decorateUrl }) => {
        if (session?.currentTask) {
          setMessage("Complete the required account task, then open the admin sign-in page.");
          return;
        }
        const url = decorateUrl("/admin");
        if (Platform.OS === "web" && url.startsWith("http")) {
          window.location.href = url;
        } else {
          router.replace("/admin");
        }
      },
    });
  };

  const createAccount = async () => {
    setMessage("");
    const result = await signUp.password({
      emailAddress: emailAddress.trim(),
      password,
    });
    if (result.error) {
      setMessage(result.error.message ?? "Account setup failed. Check your details.");
      return;
    }
    const sent = await signUp.verifications.sendEmailCode();
    if (sent.error) {
      setMessage(sent.error.message ?? "Could not send the verification code.");
      return;
    }
    setCodeSent(true);
  };

  const verifyAccount = async () => {
    setMessage("");
    const result = await signUp.verifications.verifyEmailCode({ code });
    if (result.error) {
      setMessage(result.error.message ?? "The verification code could not be confirmed.");
      return;
    }
    if (signUp.status === "complete") await finishSignUp();
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: ADMIN_COLORS.background }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: "center", padding: 22 }}>
        <View style={{ width: "100%", maxWidth: 500, alignSelf: "center", gap: 18 }}>
          <View style={{ gap: 8, paddingHorizontal: 4 }}>
            <Text style={{ color: ADMIN_COLORS.gold, fontSize: 11, fontWeight: "800", letterSpacing: 2 }}>
              ISMAIL AI CHAT
            </Text>
            <Text style={{ color: ADMIN_COLORS.text, fontSize: 30, fontWeight: "800" }}>
              Verify your account
            </Text>
            <Text style={{ color: ADMIN_COLORS.muted, fontSize: 14, lineHeight: 21 }}>
              Only verified emails listed in the server’s administrator allowlist can open the control center.
            </Text>
          </View>
          <AdminCard title={codeSent ? "Email verification" : "Account setup"}>
            <AdminNotice message="Creating a login does not grant administrator access. The server checks the verified email against its allowlist." />
            {codeSent ? (
              <>
                <AdminField
                  label="Verification code"
                  value={code}
                  onChangeText={setCode}
                  placeholder="Enter the code sent to your email"
                  keyboardType="number-pad"
                  autoCapitalize="none"
                />
                <AdminButton
                  label={busy ? "Verifying…" : "Verify email"}
                  onPress={() => void verifyAccount()}
                  disabled={!code || busy}
                />
                <AdminButton
                  label="Send another code"
                  kind="quiet"
                  onPress={() => void signUp.verifications.sendEmailCode()}
                  disabled={busy}
                />
              </>
            ) : (
              <>
                <AdminField
                  label="Email address"
                  value={emailAddress}
                  onChangeText={setEmailAddress}
                  placeholder="name@example.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoComplete="email"
                />
                <AdminField
                  label="Create password"
                  value={password}
                  onChangeText={setPassword}
                  placeholder="Use a strong password"
                  secureTextEntry
                  autoComplete="new-password"
                  autoCapitalize="none"
                />
                <AdminButton
                  label={busy ? "Sending verification…" : "Send verification code"}
                  icon="mail"
                  onPress={() => void createAccount()}
                  disabled={!emailAddress || !password || busy}
                />
              </>
            )}
            {errorMessage ? (
              <View style={{ marginTop: 12 }}>
                <AdminNotice kind="error" message={errorMessage} />
              </View>
            ) : null}
            <View nativeID="clerk-captcha" />
          </AdminCard>
          <Text style={{ color: ADMIN_COLORS.muted, textAlign: "center", fontSize: 13 }}>
            Already registered?{" "}
            <Link href="/admin/sign-in" style={{ color: ADMIN_COLORS.gold, fontWeight: "700" }}>
              Sign in
            </Link>
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
