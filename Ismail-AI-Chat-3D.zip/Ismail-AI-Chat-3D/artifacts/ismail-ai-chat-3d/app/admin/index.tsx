import { Feather } from "@expo/vector-icons";
import { useAuth, useClerk } from "@clerk/expo";
import { useGetAdminMe } from "@workspace/api-client-react";
import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  ScrollView,
  Text,
  useWindowDimensions,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  AdminButton,
  AdminCard,
  AdminNotice,
  ADMIN_COLORS,
} from "@/components/admin/shared";
import {
  AppearanceSection,
  GiftManagementSection,
  ProfileFramesSection,
  VipCatalogSection,
} from "@/components/admin/CatalogSections";
import {
  AuditSection,
  DashboardSection,
  RoomsSection,
  UsersSection,
} from "@/components/admin/AccountSections";
import { AssetLibrarySection } from "@/components/admin/AdminControls";

const sections = [
  { id: "dashboard", label: "Dashboard", icon: "grid" as const },
  { id: "gifts", label: "Gifts", icon: "gift" as const },
  { id: "studio", label: "3D Studio", icon: "box" as const },
  { id: "frames", label: "Profile frames", icon: "circle" as const },
  { id: "assets", label: "Asset library", icon: "image" as const },
  { id: "vip", label: "VIP catalog", icon: "award" as const },
  { id: "appearance", label: "App appearance", icon: "sliders" as const },
  { id: "users", label: "Users", icon: "users" as const },
  { id: "rooms", label: "Voice rooms", icon: "mic" as const },
  { id: "audit", label: "Audit history", icon: "file-text" as const },
] as const;
type SectionId = (typeof sections)[number]["id"];

function SectionContent({ section }: { section: SectionId }) {
  switch (section) {
    case "dashboard":
      return <DashboardSection />;
    case "gifts":
      return <GiftManagementSection />;
    case "studio":
      return <GiftManagementSection studio />;
    case "frames":
      return <ProfileFramesSection />;
    case "assets":
      return <AssetLibrarySection />;
    case "vip":
      return <VipCatalogSection />;
    case "appearance":
      return <AppearanceSection />;
    case "users":
      return <UsersSection />;
    case "rooms":
      return <RoomsSection />;
    case "audit":
      return <AuditSection />;
  }
}

export default function AdminControlCenterScreen() {
  const { isLoaded, isSignedIn } = useAuth();
  const clerk = useClerk();
  const router = useRouter();
  const { width } = useWindowDimensions();
  const wide = width >= 1000;
  const [section, setSection] = useState<SectionId>("dashboard");
  const admin = useGetAdminMe({
    query: { enabled: isLoaded && isSignedIn === true, retry: false },
  });

  useEffect(() => {
    if (isLoaded && !isSignedIn) router.replace("/admin/sign-in");
  }, [isLoaded, isSignedIn, router]);

  if (!isLoaded || !isSignedIn || admin.isLoading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: ADMIN_COLORS.background, alignItems: "center", justifyContent: "center", gap: 14 }}>
        <ActivityIndicator color={ADMIN_COLORS.gold} size="large" />
        <Text style={{ color: ADMIN_COLORS.muted, fontSize: 13 }}>Verifying administrator access…</Text>
      </SafeAreaView>
    );
  }

  if (admin.isError || !admin.data?.isAdmin) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: ADMIN_COLORS.background, justifyContent: "center", padding: 22 }}>
        <AdminCard title="Administrator access required">
          <AdminNotice
            kind="error"
            message="The server did not authorize this account for the admin panel. A valid sign-in alone is not enough."
          />
          <View style={{ marginTop: 14, gap: 10 }}>
            <AdminButton
              label="Sign out"
              kind="secondary"
              icon="log-out"
              onPress={async () => {
                await clerk.signOut();
                router.replace("/admin/sign-in");
              }}
            />
            <AdminButton label="Return to app" kind="quiet" onPress={() => router.replace("/")} />
          </View>
        </AdminCard>
      </SafeAreaView>
    );
  }

  const activeSection = sections.find((item) => item.id === section) ?? sections[0];
  const navigation = (
    <ScrollView
      horizontal={!wide}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{
        flexDirection: wide ? "column" : "row",
        gap: 7,
        padding: wide ? 8 : 12,
      }}
    >
      {sections.map((item) => {
        const selected = item.id === section;
        return (
          <Text
            key={item.id}
            accessibilityRole="button"
            accessibilityState={{ selected }}
            onPress={() => setSection(item.id)}
            style={{
              minHeight: 42,
              minWidth: wide ? 190 : undefined,
              paddingHorizontal: 12,
              paddingVertical: 11,
              borderRadius: 12,
              overflow: "hidden",
              backgroundColor: selected ? "rgba(124, 93, 255, 0.17)" : "transparent",
              color: selected ? ADMIN_COLORS.text : ADMIN_COLORS.muted,
              borderWidth: selected ? 1 : 0,
              borderColor: selected ? "rgba(138, 112, 255, 0.34)" : "transparent",
              fontSize: 12,
              fontWeight: selected ? "700" : "500",
              includeFontPadding: false,
            }}
          >
            <Feather
              name={item.icon}
              size={14}
              color={selected ? ADMIN_COLORS.gold : ADMIN_COLORS.muted}
            />{" "}
            {item.label}
          </Text>
        );
      })}
    </ScrollView>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: ADMIN_COLORS.background }}>
      <View
        style={{
          flex: 1,
          flexDirection: wide ? "row" : "column",
          maxWidth: 1600,
          width: "100%",
          alignSelf: "center",
        }}
      >
        {wide ? (
          <View
            style={{
              width: 230,
              borderRightWidth: 1,
              borderRightColor: ADMIN_COLORS.border,
              paddingTop: 20,
            }}
          >
            <View style={{ paddingHorizontal: 18, paddingBottom: 16, gap: 6 }}>
              <Text style={{ color: ADMIN_COLORS.gold, fontSize: 10, fontWeight: "800", letterSpacing: 1.4 }}>
                ISMAIL AI CHAT
              </Text>
              <Text style={{ color: ADMIN_COLORS.text, fontSize: 18, fontWeight: "800" }}>
                Admin Center
              </Text>
            </View>
            {navigation}
            <View style={{ padding: 14, marginTop: "auto" }}>
              <AdminButton
                label="Sign out"
                kind="quiet"
                icon="log-out"
                onPress={async () => {
                  await clerk.signOut();
                  router.replace("/admin/sign-in");
                }}
              />
            </View>
          </View>
        ) : null}

        <View style={{ flex: 1, minWidth: 0 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              paddingHorizontal: wide ? 28 : 16,
              paddingTop: wide ? 22 : 12,
              paddingBottom: 11,
              gap: 10,
            }}
          >
            <View style={{ flex: 1, gap: 4 }}>
              {!wide ? (
                <Text style={{ color: ADMIN_COLORS.gold, fontSize: 9, fontWeight: "800", letterSpacing: 1.2 }}>
                  ISMAIL AI CHAT · ADMIN
                </Text>
              ) : null}
              <Text style={{ color: ADMIN_COLORS.text, fontSize: wide ? 24 : 20, fontWeight: "800" }}>
                {activeSection.label}
              </Text>
            </View>
            <Text numberOfLines={1} style={{ color: ADMIN_COLORS.muted, maxWidth: wide ? 280 : 130, fontSize: 11 }}>
              {admin.data.email}
            </Text>
          </View>
          {!wide ? navigation : null}
          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{
              paddingHorizontal: wide ? 28 : 14,
              paddingTop: 10,
              paddingBottom: 36,
              gap: 14,
              width: "100%",
              maxWidth: 1160,
              alignSelf: "center",
            }}
            keyboardShouldPersistTaps="handled"
          >
            <SectionContent section={section} />
            {!wide ? (
              <AdminButton
                label="Sign out"
                kind="quiet"
                icon="log-out"
                onPress={async () => {
                  await clerk.signOut();
                  router.replace("/admin/sign-in");
                }}
              />
            ) : null}
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
}

