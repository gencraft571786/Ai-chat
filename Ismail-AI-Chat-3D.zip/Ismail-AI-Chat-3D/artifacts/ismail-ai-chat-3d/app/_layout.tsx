import React, { useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { AppStateProvider } from '@/components/AppState';
import { AppThemeProvider } from '@/components/AppTheme';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { ClerkProvider, useAuth } from '@clerk/expo';
import { tokenCache } from '@clerk/expo/token-cache';
import { setAuthTokenGetter, setBaseUrl } from '@workspace/api-client-react';
import { Text, View } from 'react-native';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();
const clerkPublishableKey = process.env.EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY;
const appDomain = process.env.EXPO_PUBLIC_DOMAIN?.replace(/^https?:\/\//, '').replace(/\/+$/, '');
if (appDomain) setBaseUrl(`https://${appDomain}`);

const clerkProxyUrl =
  process.env.EXPO_PUBLIC_CLERK_PROXY_URL ||
  (process.env.NODE_ENV === 'production' && appDomain
    ? `https://${appDomain}/api/__clerk`
    : undefined);

function AuthApiBridge() {
  const { getToken } = useAuth();

  useEffect(() => {
    // Expo uses bearer tokens for authenticated API requests on native and web.
    setAuthTokenGetter(() => getToken());
    return () => setAuthTokenGetter(null);
  }, [getToken]);

  return null;
}

function MissingClerkConfiguration() {
  return (
    <View style={{ flex: 1, backgroundColor: '#080B16', justifyContent: 'center', padding: 28 }}>
      <Text style={{ color: '#F6F2E8', fontSize: 20, fontWeight: '700' }}>
        Sign-in is not configured
      </Text>
      <Text style={{ color: '#A9B0C2', marginTop: 10, lineHeight: 22 }}>
        The app needs its managed authentication configuration before it can start.
      </Text>
    </View>
  );
}

function RootLayoutNav() {
  return (
    <Stack
      screenOptions={{
        headerBackTitle: 'Back',
        headerShown: false,
        contentStyle: { backgroundColor: '#080B16' },
      }}
    >
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="assistant" options={{ headerShown: false, presentation: 'modal' }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    clerkPublishableKey ? (
      <ClerkProvider
        publishableKey={clerkPublishableKey}
        tokenCache={tokenCache}
        proxyUrl={clerkProxyUrl}
      >
        <SafeAreaProvider>
          <ErrorBoundary>
            <QueryClientProvider client={queryClient}>
              <AuthApiBridge />
              <AppThemeProvider>
                <AppStateProvider>
                  <GestureHandlerRootView style={{ flex: 1 }}>
                    <KeyboardProvider>
                      <StatusBar style="light" />
                      <RootLayoutNav />
                    </KeyboardProvider>
                  </GestureHandlerRootView>
                </AppStateProvider>
              </AppThemeProvider>
            </QueryClientProvider>
          </ErrorBoundary>
        </SafeAreaProvider>
      </ClerkProvider>
    ) : (
      <MissingClerkConfiguration />
    )
  );
}
