import { AssistantScreen } from '@/screens/FeatureScreens';
export default AssistantScreen;
