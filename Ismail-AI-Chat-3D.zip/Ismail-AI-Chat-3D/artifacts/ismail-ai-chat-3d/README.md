# Ismail AI Chat 3D

An Android-first Expo / React Native social app foundation with a premium dark interface, profile-frame previews, and navigation for Home, Messages, Rooms, Gifts, and Profile.

## Run the mobile preview

1. Open this Replit project and start the managed `artifacts/ismail-ai-chat-3d: expo` workflow.
2. To test on an Android phone, open **Preview on your phone** and scan its QR code with Expo Go.
3. The project can also be viewed in the in-browser mobile preview.

The managed workflow supplies the runtime networking and preview settings. Avoid starting Expo with a bare `expo start` command.

## Available in this first milestone

- Five-screen mobile navigation plus an Ismail AI screen.
- Premium dark surfaces, metallic-gold accents, generated app art, and profile-frame color treatments.
- Photo selection from the device's image library.
- Locally saved profile photo and selected frame preferences.
- Search and unread filtering for clearly labeled sample conversations.
- Interactive gift and room previews that explicitly do not send gifts or connect to live audio.
- Honest status labels for services that are not connected.

## Not connected yet

These features need separate implementation and provider setup before they can be used as live services:

- Sign-up, sign-in, user profiles, friend requests, blocking, and reporting.
- Private messaging, conversation history, presence, typing indicators, delivery/read receipts, and synchronized media uploads.
- Push notifications.
- Live voice-room audio, host/moderator permissions, and participant synchronization.
- A server-side gift catalog, inventory, gift history, and authoritative credit ledger.
- VIP subscriptions and secure payment processing.
- A secure backend connection for Urdu, Roman Urdu, and English AI conversations.

Sample activity shown in the preview is illustrative only. Local profile preferences are stored on the device and do not sync to an account. No purchase, message, gift, or AI reply is represented as successful.

## Project structure

- `app/` — Expo Router screens and tab navigation.
- `screens/` — Home and feature-screen interfaces.
- `components/` — Shared visual components and local preview state.
- `constants/colors.ts` — Dark navy, glass, and gold palette.
- `assets/images/` — App icon and generated preview imagery.

This is source code for a native-capable Expo app. This milestone does not include an Android APK or Google Play submission.
