/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#F6F2E8',
    tint: '#D6B46D',
    background: '#080B16',
    foreground: '#F6F2E8',
    card: '#111626',
    cardForeground: '#F6F2E8',
    primary: '#D6B46D',
    primaryForeground: '#080B16',
    secondary: '#171D2C',
    secondaryForeground: '#F6F2E8',
    muted: '#171D2C',
    mutedForeground: '#9299AA',
    accent: '#1A2131',
    accentForeground: '#F6F2E8',
    destructive: '#D75A60',
    destructiveForeground: '#FFFFFF',
    border: '#252C3D',
    input: '#252C3D',
    surface: '#111626',
    surfaceRaised: '#1A2131',
    tabBar: '#0D1120',
    gold: '#D6B46D',
    goldBright: '#F0D394',
    goldBorder: 'rgba(214, 180, 109, .34)',
    goldWash: 'rgba(214, 180, 109, .12)',
    heroTop: '#18213A',
    heroBottom: '#0B1021',
    heroText: '#B6BDD0',
    glass: 'rgba(255, 255, 255, .09)',
    online: '#50C99B',
    warning: '#E4AF5B',
    danger: '#D85C68',
    crystal: '#7EC8F4',
    amethyst: '#B58BEA',
    frameColors: {
      gold: '#E1BB69',
      diamond: '#8BD3F7',
      crystal: '#AE9BFA',
      rainbow: '#E287D8',
      fire: '#F17D53',
      ice: '#78D7ED',
      galaxy: '#BD8BEF',
    },
  },
  dark: {
    text: '#F6F2E8',
    tint: '#D6B46D',
    background: '#080B16',
    foreground: '#F6F2E8',
    card: '#111626',
    cardForeground: '#F6F2E8',
    primary: '#D6B46D',
    primaryForeground: '#080B16',
    secondary: '#171D2C',
    secondaryForeground: '#F6F2E8',
    muted: '#171D2C',
    mutedForeground: '#9299AA',
    accent: '#1A2131',
    accentForeground: '#F6F2E8',
    destructive: '#D75A60',
    destructiveForeground: '#FFFFFF',
    border: '#252C3D',
    input: '#252C3D',
    surface: '#111626',
    surfaceRaised: '#1A2131',
    tabBar: '#0D1120',
    gold: '#D6B46D',
    goldBright: '#F0D394',
    goldBorder: 'rgba(214, 180, 109, .34)',
    goldWash: 'rgba(214, 180, 109, .12)',
    heroTop: '#18213A',
    heroBottom: '#0B1021',
    heroText: '#B6BDD0',
    glass: 'rgba(255, 255, 255, .09)',
    online: '#50C99B',
    warning: '#E4AF5B',
    danger: '#D85C68',
    crystal: '#7EC8F4',
    amethyst: '#B58BEA',
    frameColors: {
      gold: '#E1BB69',
      diamond: '#8BD3F7',
      crystal: '#AE9BFA',
      rainbow: '#E287D8',
      fire: '#F17D53',
      ice: '#78D7ED',
      galaxy: '#BD8BEF',
    },
  },

  radius: 18,
};

export default colors;
