import { Platform } from "react-native";

export function resolveApiUrl(path: string) {
  if (/^https?:\/\//i.test(path)) return path;
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const appDomain = process.env.EXPO_PUBLIC_DOMAIN?.replace(/^https?:\/\//, "").replace(/\/+$/, "");
  if (appDomain) return `https://${appDomain}${normalizedPath}`;
  if (Platform.OS === "web" && typeof window !== "undefined") {
    return new URL(normalizedPath, window.location.origin).toString();
  }
  return normalizedPath;
}
