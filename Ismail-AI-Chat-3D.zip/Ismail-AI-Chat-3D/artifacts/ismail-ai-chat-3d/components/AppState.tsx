import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';

export type FrameId = string;

interface AppStateValue {
  activeFrame: FrameId;
  profileImage: string | null;
  isLoaded: boolean;
  setActiveFrame: (frame: FrameId) => void;
  setProfileImage: (uri: string | null) => void;
}

const AppStateContext = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [activeFrame, setFrame] = useState<FrameId>('gold');
  const [profileImage, setImage] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    let isMounted = true;
    void (async () => {
      try {
        const [savedFrame, savedImage] = await Promise.all([
          AsyncStorage.getItem('ismail-chat:profile-frame'),
          AsyncStorage.getItem('ismail-chat:profile-image'),
        ]);
        if (!isMounted) return;
        if (savedFrame) setFrame(savedFrame);
        if (savedImage) setImage(savedImage);
      } catch {
        // Local preferences are optional; the preview remains usable if storage
        // is unavailable on a device.
      } finally {
        if (isMounted) setIsLoaded(true);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, []);

  const setActiveFrame = (frame: FrameId) => {
    setFrame(frame);
    void AsyncStorage.setItem('ismail-chat:profile-frame', frame);
  };

  const setProfileImage = (uri: string | null) => {
    setImage(uri);
    if (uri) {
      void AsyncStorage.setItem('ismail-chat:profile-image', uri);
    } else {
      void AsyncStorage.removeItem('ismail-chat:profile-image');
    }
  };

  const value = useMemo(
    () => ({
      activeFrame,
      profileImage,
      isLoaded,
      setActiveFrame,
      setProfileImage,
    }),
    [activeFrame, profileImage, isLoaded],
  );

  return (
    <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>
  );
}

export function useAppState() {
  const state = useContext(AppStateContext);
  if (!state) {
    throw new Error('useAppState must be used within AppStateProvider');
  }
  return state;
}
