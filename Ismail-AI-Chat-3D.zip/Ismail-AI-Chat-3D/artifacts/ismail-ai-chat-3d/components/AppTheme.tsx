import React, { createContext, useContext, type ReactNode } from "react";
import { useGetPublicCatalog } from "@workspace/api-client-react";

export type AppThemeTokens = {
  background: string;
  surface: string;
  primary: string;
  secondary: string;
  accent: string;
};

const defaultTheme: AppThemeTokens = {
  background: "#080B16",
  surface: "#111626",
  primary: "#7958F5",
  secondary: "#288EFF",
  accent: "#D8B55A",
};

const AppThemeContext = createContext<AppThemeTokens>(defaultTheme);

export function AppThemeProvider({ children }: { children: ReactNode }) {
  const catalog = useGetPublicCatalog({
    query: { retry: false, staleTime: 60_000 },
  });
  const theme = catalog.data?.settings.theme ?? defaultTheme;

  return (
    <AppThemeContext.Provider value={theme}>
      {children}
    </AppThemeContext.Provider>
  );
}

export function useAppTheme() {
  return useContext(AppThemeContext);
}

