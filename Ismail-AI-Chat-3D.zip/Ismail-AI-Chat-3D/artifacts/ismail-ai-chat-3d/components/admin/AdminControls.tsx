import { Feather } from "@expo/vector-icons";
import {
  getGetAdminAssetsQueryKey,
  useCompleteAdminAssetUpload,
  useDeleteAdminAsset,
  useGetAdminAssetPreviewUrl,
  useGetAdminAssets,
  useRequestAdminAssetUpload,
} from "@workspace/api-client-react";
import type { AdminAsset, AssetUploadRequestKind } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import * as DocumentPicker from "expo-document-picker";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { AssetMediaPreview } from "./AssetMediaPreview";
import {
  AdminButton,
  AdminCard,
  AdminField,
  AdminNotice,
  AdminPill,
  ADMIN_COLORS,
  formatBytes,
  formatDate,
} from "./shared";

const mimeByExtension: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  mp4: "video/mp4",
  glb: "model/gltf-binary",
  gltf: "model/gltf+json",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  ogg: "audio/ogg",
  m4a: "audio/mp4",
};

export function AssetPicker({
  label,
  assetId,
  onChange,
  assets,
  filter,
}: {
  label: string;
  assetId: string | null;
  onChange: (assetId: string | null) => void;
  assets: AdminAsset[];
  filter: (asset: AdminAsset) => boolean;
}) {
  const options = useMemo(() => assets.filter(filter), [assets, filter]);
  return (
    <View style={{ gap: 8, marginBottom: 14 }}>
      <Text style={{ color: "#BDC5D7", fontSize: 12, fontWeight: "600" }}>{label}</Text>
      {options.length ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
          <AdminPill label="None" active={!assetId} onPress={() => onChange(null)} />
          {options.map((asset) => (
            <AdminPill
              key={asset.id}
              label={`${asset.name} · ${formatBytes(asset.sizeBytes)}`}
              active={asset.id === assetId}
              onPress={() => onChange(asset.id)}
            />
          ))}
        </ScrollView>
      ) : (
        <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12 }}>
          No compatible assets yet. Upload one in Asset Library first.
        </Text>
      )}
    </View>
  );
}

export function SignedAssetPreview({
  assetId,
  asset,
  scale,
  rotationX,
  rotationY,
  rotationZ,
}: {
  assetId: string | null;
  asset?: AdminAsset;
  scale?: number;
  rotationX?: number;
  rotationY?: number;
  rotationZ?: number;
}) {
  const query = useGetAdminAssetPreviewUrl(assetId ?? "", {
    query: { enabled: Boolean(assetId), retry: false },
  });
  if (!assetId) {
    return <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12 }}>Select an asset to preview it.</Text>;
  }
  if (query.isLoading) {
    return <ActivityIndicator color={ADMIN_COLORS.gold} style={{ padding: 20 }} />;
  }
  if (query.isError || !query.data?.url) {
    return <AdminNotice kind="error" message="This asset could not be previewed. The stored file may be missing." />;
  }
  return (
    <AssetMediaPreview
      uri={query.data.url}
      contentType={asset?.contentType ?? "application/octet-stream"}
      scale={scale}
      rotationX={rotationX}
      rotationY={rotationY}
      rotationZ={rotationZ}
    />
  );
}

export function AssetUploader({
  kind,
  onUploaded,
}: {
  kind: AssetUploadRequestKind;
  onUploaded?: (asset: AdminAsset) => void;
}) {
  const requestUpload = useRequestAdminAssetUpload();
  const completeUpload = useCompleteAdminAssetUpload();
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const pickAndUpload = async () => {
    setMessage("");
    setError("");
    const picked = await DocumentPicker.getDocumentAsync({
      type: ["image/*", "video/mp4", "model/gltf-binary", "model/gltf+json", "audio/*"],
      copyToCacheDirectory: true,
      multiple: false,
    });
    if (picked.canceled || !picked.assets[0]) return;
    const file = picked.assets[0];
    const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
    const contentType = mimeByExtension[extension];
    if (!contentType) {
      setError("Supported formats: PNG, JPEG, GIF, WebP, MP4, GLB, self-contained glTF, MP3, WAV and OGG.");
      return;
    }

    setUploading(true);
    try {
      const blob = file.file ?? await (await fetch(file.uri)).blob();
      const sizeBytes = file.size ?? blob.size;
      if (!sizeBytes) throw new Error("The selected file size could not be read.");
      const ticket = await requestUpload.mutateAsync({
        data: { name: file.name, contentType, sizeBytes, kind },
      });
      const uploadResponse = await fetch(ticket.uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": contentType },
        body: blob,
      });
      if (!uploadResponse.ok) {
        throw new Error(`Storage rejected the upload (HTTP ${uploadResponse.status}).`);
      }
      const asset = await completeUpload.mutateAsync({
        data: { pendingUploadId: ticket.pendingUploadId },
      });
      await queryClient.invalidateQueries({ queryKey: getGetAdminAssetsQueryKey() });
      setMessage(`${asset.name} was uploaded and verified.`);
      onUploaded?.(asset);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "The upload could not be completed.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <View style={{ gap: 10 }}>
      <AdminButton
        label={uploading ? "Uploading and verifying…" : "Choose file and upload"}
        icon={uploading ? undefined : "upload-cloud"}
        onPress={() => void pickAndUpload()}
        disabled={uploading}
      />
      <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, lineHeight: 17 }}>
        Images/GIF/WebP up to 15 MB; MP4 up to 100 MB; GLB up to 60 MB; self-contained glTF up to 10 MB; audio up to 20 MB. Files are checked on the server before they enter the library.
      </Text>
      {message ? <AdminNotice kind="success" message={message} /> : null}
      {error ? <AdminNotice kind="error" message={error} /> : null}
    </View>
  );
}

function confirmDelete(asset: AdminAsset, onConfirm: () => void) {
  const action = () => {
    if (asset.referenceCount > 0) return;
    if (Platform.OS === "web" && typeof window !== "undefined") {
      if (window.confirm(`Delete ${asset.name}? This cannot be undone.`)) onConfirm();
      return;
    }
    Alert.alert("Delete asset?", `Delete ${asset.name}? This cannot be undone.`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: onConfirm },
    ]);
  };
  action();
}

export function AssetLibrarySection() {
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState("");
  const [preview, setPreview] = useState<AdminAsset | null>(null);
  const assets = useGetAdminAssets({ search: search || undefined, kind: kind || undefined });
  const removeAsset = useDeleteAdminAsset();
  const [error, setError] = useState("");
  const list = assets.data ?? [];

  const remove = (asset: AdminAsset) =>
    confirmDelete(asset, () => {
      setError("");
      removeAsset.mutate(
        { id: asset.id },
        {
          onSuccess: () => {
            void assets.refetch();
            setPreview((current) => (current?.id === asset.id ? null : current));
          },
          onError: (caught) =>
            setError(caught instanceof Error ? caught.message : "Asset deletion failed."),
        },
      );
    });

  return (
    <View style={{ gap: 14 }}>
      <AdminCard title="Verified asset library" subtitle="Private files stay protected until published content references them.">
        <AdminField
          label="Search assets"
          value={search}
          onChangeText={setSearch}
          placeholder="Name or file type"
          autoCapitalize="none"
        />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, marginBottom: 14 }}>
          {["", "gift-image", "gift-thumbnail", "gift-model", "frame", "audio", "video", "banner", "vip-badge"].map((option) => (
            <AdminPill
              key={option || "all"}
              label={option ? option.replace("-", " ") : "All types"}
              active={kind === option}
              onPress={() => setKind(option)}
            />
          ))}
        </ScrollView>
        <AssetUploader kind="other" onUploaded={() => void assets.refetch()} />
        {error ? <View style={{ marginTop: 12 }}><AdminNotice kind="error" message={error} /></View> : null}
      </AdminCard>

      {preview ? (
        <AdminCard title={preview.name} subtitle={`${preview.contentType} · ${formatBytes(preview.sizeBytes)}`}>
          <SignedAssetPreview assetId={preview.id} asset={preview} />
          <View style={{ marginTop: 12 }}>
            <AdminButton label="Close preview" kind="quiet" onPress={() => setPreview(null)} />
          </View>
        </AdminCard>
      ) : null}

      {assets.isLoading ? (
        <AdminCard><ActivityIndicator color={ADMIN_COLORS.gold} /></AdminCard>
      ) : assets.isError ? (
        <AdminNotice kind="error" message="Asset records could not be loaded from the server." />
      ) : list.length === 0 ? (
        <AdminCard title="No assets yet">
          <Text style={{ color: ADMIN_COLORS.muted, fontSize: 13, lineHeight: 20 }}>
            Upload a supported image, animation, sound or model to begin building the catalog.
          </Text>
        </AdminCard>
      ) : (
        <View style={{ gap: 10 }}>
          {list.map((asset) => (
            <AdminCard key={asset.id}>
              <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 12 }}>
                <View style={{ width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(133,103,255,.15)" }}>
                  <Feather
                    name={asset.contentType.startsWith("image/") ? "image" : asset.contentType.startsWith("audio/") ? "music" : asset.contentType.startsWith("model/") ? "box" : "film"}
                    size={17}
                    color={ADMIN_COLORS.gold}
                  />
                </View>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text style={{ color: ADMIN_COLORS.text, fontSize: 14, fontWeight: "700" }} numberOfLines={1}>{asset.name}</Text>
                  <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11 }}>
                    {asset.contentType} · {formatBytes(asset.sizeBytes)} · {formatDate(asset.uploadedAt)}
                  </Text>
                  <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11 }}>
                    {asset.referenceCount} catalog reference{asset.referenceCount === 1 ? "" : "s"}
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 14 }}>
                <AdminButton label="Preview" kind="secondary" compact icon="eye" onPress={() => setPreview(asset)} />
                <AdminButton
                  label={removeAsset.isPending ? "Deleting…" : "Delete"}
                  kind="danger"
                  compact
                  icon="trash-2"
                  disabled={asset.referenceCount > 0 || removeAsset.isPending}
                  onPress={() => remove(asset)}
                />
              </View>
              {asset.referenceCount > 0 ? (
                <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, marginTop: 8 }}>
                  Remove this asset from catalog entries before deleting it.
                </Text>
              ) : null}
            </AdminCard>
          ))}
        </View>
      )}
    </View>
  );
}

