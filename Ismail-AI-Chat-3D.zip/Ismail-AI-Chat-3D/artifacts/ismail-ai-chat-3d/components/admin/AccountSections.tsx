import { Feather } from "@expo/vector-icons";
import {
  useBanAdminUser,
  useGetAdminAuditLogs,
  useGetAdminOverview,
  useGetAdminRooms,
  useGetAdminUsers,
  useUnbanAdminUser,
} from "@workspace/api-client-react";
import type { AdminUser } from "@workspace/api-client-react";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  Text,
  View,
} from "react-native";
import {
  AdminButton,
  AdminCard,
  AdminField,
  AdminNotice,
  AdminPill,
  ADMIN_COLORS,
  formatBytes,
  formatDate,
} from "./shared";

function confirmModeration(title: string, message: string, onConfirm: () => void) {
  if (Platform.OS === "web" && typeof window !== "undefined") {
    if (window.confirm(`${title}\n\n${message}`)) onConfirm();
    return;
  }
  Alert.alert(title, message, [
    { text: "Cancel", style: "cancel" },
    { text: "Continue", style: "destructive", onPress: onConfirm },
  ]);
}

function Metric({
  label,
  value,
  icon,
  hint,
}: {
  label: string;
  value: string;
  icon: keyof typeof Feather.glyphMap;
  hint?: string;
}) {
  return (
    <AdminCard style={{ flexGrow: 1, minWidth: 145, flexBasis: 145 }}>
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
        <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, fontWeight: "600" }}>{label}</Text>
        <Feather name={icon} size={15} color={ADMIN_COLORS.gold} />
      </View>
      <Text style={{ color: ADMIN_COLORS.text, fontSize: 25, fontWeight: "800", marginTop: 10 }}>{value}</Text>
      {hint ? <Text style={{ color: ADMIN_COLORS.muted, fontSize: 10, marginTop: 5 }}>{hint}</Text> : null}
    </AdminCard>
  );
}

export function DashboardSection() {
  const overview = useGetAdminOverview({ query: { retry: false } });
  const audit = useGetAdminAuditLogs({ query: { retry: false } });
  const rooms = useGetAdminRooms({ query: { retry: false } });
  const data = overview.data;
  const metrics = [
    {
      label: "Registered users",
      value: data?.registeredUsers == null ? "Unavailable" : data.registeredUsers.toLocaleString(),
      icon: "users" as const,
      hint: "Count from Clerk",
    },
    {
      label: "Active users",
      value: data?.activeUsers == null ? "Not tracked" : data.activeUsers.toLocaleString(),
      icon: "activity" as const,
      hint: "No reliable activity source is connected",
    },
    {
      label: "Gift records",
      value: data ? data.totalGifts.toLocaleString() : "—",
      icon: "gift" as const,
      hint: "All statuses",
    },
    {
      label: "Profile frames",
      value: data ? data.totalFrames.toLocaleString() : "—",
      icon: "circle" as const,
      hint: "All statuses",
    },
    {
      label: "Voice rooms",
      value: data?.voiceRoomsTracked ? String(data.voiceRooms ?? 0) : "Not connected",
      icon: "mic" as const,
      hint: "Room provider is not configured",
    },
    {
      label: "Managed asset bytes",
      value: data ? formatBytes(data.totalStorageBytes) : "—",
      icon: "hard-drive" as const,
      hint: "Registered asset files only",
    },
  ];
  return (
    <View style={{ gap: 14 }}>
      {overview.isLoading ? (
        <AdminCard><ActivityIndicator color={ADMIN_COLORS.gold} /></AdminCard>
      ) : overview.isError ? (
        <AdminNotice kind="error" message="Dashboard metrics could not be loaded. The panel has not substituted sample statistics." />
      ) : null}
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
        {metrics.map((metric) => (
          <Metric key={metric.label} {...metric} />
        ))}
      </View>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 14 }}>
        <AdminCard
          title="Gift activity"
          subtitle={
            data?.giftActivityTracked
              ? "Recent send activity from the connected gift service."
              : "Gift sending and purchase records are not tracked in this app yet."
          }
          style={{ flexGrow: 1, flexBasis: 270 }}
        >
          {data?.giftActivityTracked && data.recentGiftActivity.length ? (
            data.recentGiftActivity.map((activity, index) => (
              <Text key={index} style={{ color: ADMIN_COLORS.muted, fontSize: 12, paddingVertical: 5 }}>
                {JSON.stringify(activity)}
              </Text>
            ))
          ) : (
            <AdminNotice message="No gift transaction data is available. Catalog administration does not send gifts or change balances." />
          )}
        </AdminCard>
        <AdminCard
          title="Voice rooms"
          subtitle={rooms.data?.message ?? "Checking room-service availability…"}
          style={{ flexGrow: 1, flexBasis: 270 }}
        >
          {rooms.isLoading ? <ActivityIndicator color={ADMIN_COLORS.gold} /> : null}
          {rooms.data?.tracked ? (
            <Text style={{ color: ADMIN_COLORS.text }}>{rooms.data.rooms.length} room records</Text>
          ) : (
            <AdminNotice message="Room listings and moderation are not available until a live voice-room provider is connected." />
          )}
        </AdminCard>
      </View>
      <AdminCard title="Recent administrative changes" subtitle="Important edits and moderation actions are recorded on the server.">
        {audit.isLoading ? <ActivityIndicator color={ADMIN_COLORS.gold} /> : null}
        {audit.isError ? <AdminNotice kind="error" message="Audit records could not be loaded." /> : null}
        {!audit.isLoading && !audit.isError && (audit.data?.length ?? 0) === 0 ? (
          <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12 }}>No administrative changes have been recorded yet.</Text>
        ) : null}
        {(audit.data ?? []).slice(0, 6).map((entry) => (
          <View key={entry.id} style={{ paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: ADMIN_COLORS.border, gap: 4 }}>
            <Text style={{ color: ADMIN_COLORS.text, fontSize: 12, fontWeight: "600" }}>
              {entry.action.replaceAll(".", " ")} · {entry.entityType}
            </Text>
            <Text style={{ color: ADMIN_COLORS.muted, fontSize: 10 }}>
              {entry.actorEmail} · {formatDate(entry.createdAt)}
            </Text>
          </View>
        ))}
      </AdminCard>
    </View>
  );
}

export function UsersSection() {
  const [search, setSearch] = useState("");
  const [reasonByUser, setReasonByUser] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const users = useGetAdminUsers({ search: search || undefined });
  const ban = useBanAdminUser();
  const unban = useUnbanAdminUser();

  const banUser = (user: AdminUser) => {
    const reason = reasonByUser[user.id]?.trim() ?? "";
    if (reason.length < 3) {
      setError("Enter a moderation reason of at least three characters.");
      return;
    }
    confirmModeration(
      "Ban this account?",
      `${user.fullName} will be banned through the identity provider and will not be able to sign in.`,
      () => {
        setError("");
        ban.mutate(
          { id: user.id, data: { reason } },
          {
            onSuccess: () => void users.refetch(),
            onError: (caught) => setError(caught instanceof Error ? caught.message : "The user could not be banned."),
          },
        );
      },
    );
  };
  const unbanUser = (user: AdminUser) =>
    confirmModeration("Restore this account?", `Allow ${user.fullName} to sign in again?`, () => {
      setError("");
      unban.mutate(
        { id: user.id },
        {
          onSuccess: () => void users.refetch(),
          onError: (caught) => setError(caught instanceof Error ? caught.message : "The user could not be restored."),
        },
      );
    });

  return (
    <View style={{ gap: 14 }}>
      <AdminCard title="User accounts" subtitle="Search Clerk accounts and apply account-level moderation. Every moderation action is audited.">
        <AdminField label="Search users" value={search} onChangeText={setSearch} placeholder="Name, email or username" autoCapitalize="none" />
        <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, lineHeight: 17 }}>
          Ban and restore actions are performed server-side through the identity provider. Administrators cannot moderate their own or another administrator account.
        </Text>
      </AdminCard>
      {error ? <AdminNotice kind="error" message={error} /> : null}
      {users.isLoading ? <AdminCard><ActivityIndicator color={ADMIN_COLORS.gold} /></AdminCard> : null}
      {users.isError ? <AdminNotice kind="error" message="User records could not be loaded." /> : null}
      {!users.isLoading && !users.isError && (users.data?.length ?? 0) === 0 ? (
        <AdminCard title="No matching accounts"><Text style={{ color: ADMIN_COLORS.muted, fontSize: 13 }}>Try a different name or email.</Text></AdminCard>
      ) : null}
      {(users.data ?? []).map((user) => (
        <AdminCard key={user.id}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            {user.imageUrl ? (
              <Image
                source={{ uri: user.imageUrl }}
                style={{ width: 42, height: 42, borderRadius: 22, backgroundColor: ADMIN_COLORS.panelLight }}
                accessibilityLabel={`${user.fullName} profile image`}
              />
            ) : (
              <View style={{ width: 42, height: 42, borderRadius: 22, backgroundColor: ADMIN_COLORS.panelLight, alignItems: "center", justifyContent: "center" }}>
                <Feather name="user" size={18} color={ADMIN_COLORS.muted} />
              </View>
            )}
            <View style={{ flex: 1, gap: 3 }}>
              <Text style={{ color: ADMIN_COLORS.text, fontWeight: "700" }}>{user.fullName}</Text>
              <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11 }}>{user.email}</Text>
              <Text style={{ color: ADMIN_COLORS.muted, fontSize: 10 }}>Joined {formatDate(user.createdAt)}</Text>
            </View>
            <AdminPill label={user.banned ? "Banned" : "Active"} active={!user.banned} />
          </View>
          {!user.banned ? (
            <>
              <View style={{ marginTop: 12 }}>
                <AdminField
                  label="Moderation reason"
                  value={reasonByUser[user.id] ?? ""}
                  onChangeText={(value) => setReasonByUser((current) => ({ ...current, [user.id]: value }))}
                  placeholder="Required for an audit entry"
                  multiline
                />
              </View>
              <AdminButton label={ban.isPending ? "Applying…" : "Ban account"} kind="danger" compact icon="slash" onPress={() => banUser(user)} disabled={ban.isPending || (reasonByUser[user.id]?.trim().length ?? 0) < 3} />
            </>
          ) : (
            <View style={{ marginTop: 12 }}>
              <AdminButton label={unban.isPending ? "Restoring…" : "Restore account"} kind="secondary" compact icon="user-check" onPress={() => unbanUser(user)} disabled={unban.isPending} />
            </View>
          )}
        </AdminCard>
      ))}
    </View>
  );
}

export function RoomsSection() {
  const rooms = useGetAdminRooms();
  return (
    <AdminCard title="Voice room records" subtitle="Room administration requires the live voice provider to send room records to the API.">
      {rooms.isLoading ? <ActivityIndicator color={ADMIN_COLORS.gold} /> : null}
      {rooms.isError ? <AdminNotice kind="error" message="Room-service availability could not be checked." /> : null}
      {rooms.data?.tracked ? (
        <Text style={{ color: ADMIN_COLORS.text }}>{rooms.data.rooms.length} room records are available.</Text>
      ) : (
        <AdminNotice message={rooms.data?.message ?? "No room service is connected; the admin panel will not invent room records."} />
      )}
    </AdminCard>
  );
}

export function AuditSection() {
  const logs = useGetAdminAuditLogs();
  return (
    <View style={{ gap: 14 }}>
      <AdminCard title="Audit history" subtitle="Server-recorded administrative changes. Entries are read-only from this screen.">
        {logs.isLoading ? <ActivityIndicator color={ADMIN_COLORS.gold} /> : null}
        {logs.isError ? <AdminNotice kind="error" message="Audit history could not be loaded." /> : null}
        {!logs.isLoading && !logs.isError && (logs.data?.length ?? 0) === 0 ? (
          <Text style={{ color: ADMIN_COLORS.muted, fontSize: 13 }}>No administrative actions have been recorded yet.</Text>
        ) : null}
        {(logs.data ?? []).map((entry) => (
          <View key={entry.id} style={{ borderTopWidth: 1, borderTopColor: ADMIN_COLORS.border, paddingVertical: 12, gap: 4 }}>
            <Text style={{ color: ADMIN_COLORS.text, fontSize: 13, fontWeight: "700" }}>
              {entry.action.replaceAll(".", " ")}
            </Text>
            <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11 }}>
              {entry.actorEmail} · {entry.entityType}{entry.entityId ? ` · ${entry.entityId}` : ""}
            </Text>
            <Text style={{ color: ADMIN_COLORS.muted, fontSize: 10 }}>{formatDate(entry.createdAt)}</Text>
            {Object.keys(entry.details ?? {}).length > 0 ? (
              <Text style={{ color: "#8792AA", fontSize: 10, lineHeight: 15 }}>
                {JSON.stringify(entry.details)}
              </Text>
            ) : null}
          </View>
        ))}
      </AdminCard>
    </View>
  );
}

