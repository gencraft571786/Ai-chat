import React from "react";
import { Text, View } from "react-native";
import { ADMIN_COLORS } from "./shared";

export function GltfModelPreview() {
  return (
    <View
      accessibilityRole="summary"
      style={{
        minHeight: 180,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: ADMIN_COLORS.border,
        backgroundColor: "#0B1020",
        alignItems: "center",
        justifyContent: "center",
        padding: 18,
      }}
    >
      <Text style={{ color: ADMIN_COLORS.text, fontWeight: "700", textAlign: "center" }}>
        3D preview is not available in the native Expo viewer.
      </Text>
      <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 7 }}>
        Upload and configure GLB or self-contained glTF assets here. Open the admin panel in a desktop browser to rotate and inspect the model.
      </Text>
    </View>
  );
}
