import { Feather } from "@expo/vector-icons";
import { useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import { VideoView, useVideoPlayer } from "expo-video";
import React from "react";
import { Image } from "expo-image";
import { Pressable, Text, View } from "react-native";
import { GltfModelPreview } from "./GltfModelPreview";
import { ADMIN_COLORS } from "./shared";

function AudioPreview({ uri }: { uri: string }) {
  const player = useAudioPlayer(uri);
  const status = useAudioPlayerStatus(player);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={status.playing ? "Pause audio preview" : "Play audio preview"}
      onPress={() => (status.playing ? player.pause() : player.play())}
      style={{
        minHeight: 72,
        borderRadius: 12,
        backgroundColor: "#0B1020",
        borderWidth: 1,
        borderColor: ADMIN_COLORS.border,
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "row",
        gap: 10,
      }}
    >
      <Feather name={status.playing ? "pause" : "play"} size={18} color={ADMIN_COLORS.gold} />
      <Text style={{ color: ADMIN_COLORS.text, fontSize: 13, fontWeight: "600" }}>
        {status.playing ? "Playing sound preview" : "Play sound preview"}
      </Text>
    </Pressable>
  );
}

function VideoPreview({ uri }: { uri: string }) {
  const player = useVideoPlayer(uri, (instance) => {
    instance.loop = false;
  });
  return (
    <VideoView
      player={player}
      nativeControls
      contentFit="contain"
      style={{
        width: "100%",
        height: 220,
        borderRadius: 12,
        backgroundColor: "#0B1020",
      }}
    />
  );
}

export function AssetMediaPreview({
  uri,
  contentType,
  scale = 1,
  rotationX = 0,
  rotationY = 0,
  rotationZ = 0,
}: {
  uri: string;
  contentType: string;
  scale?: number;
  rotationX?: number;
  rotationY?: number;
  rotationZ?: number;
}) {
  if (contentType.startsWith("image/")) {
    return (
      <Image
        source={{ uri }}
        contentFit="contain"
        accessibilityLabel="Uploaded asset preview"
        style={{
          width: "100%",
          height: 210,
          borderRadius: 12,
          backgroundColor: "#0B1020",
        }}
      />
    );
  }
  if (contentType === "video/mp4") return <VideoPreview uri={uri} />;
  if (contentType.startsWith("audio/")) return <AudioPreview uri={uri} />;
  if (contentType === "model/gltf-binary" || contentType === "model/gltf+json") {
    return (
      <GltfModelPreview
        uri={uri}
        scale={scale}
        rotationX={rotationX}
        rotationY={rotationY}
        rotationZ={rotationZ}
      />
    );
  }
  return (
    <View
      style={{
        minHeight: 72,
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: ADMIN_COLORS.border,
      }}
    >
      <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12 }}>
        Preview is not supported for {contentType}.
      </Text>
    </View>
  );
}
