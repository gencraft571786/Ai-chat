import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

export function GltfModelPreview({
  uri,
  scale = 1,
  rotationX = 0,
  rotationY = 0,
  rotationZ = 0,
}: {
  uri: string;
  scale?: number;
  rotationX?: number;
  rotationY?: number;
  rotationZ?: number;
}) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const host = hostRef.current;
    if (!host || !uri) return;
    let disposed = false;
    let frame = 0;
    let model: THREE.Object3D | null = null;
    let renderer: THREE.WebGLRenderer | null = null;
    let controls: OrbitControls | null = null;

    try {
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#0D1425");
      const width = Math.max(host.clientWidth, 260);
      const height = Math.max(host.clientHeight, 190);
      const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 1000);
      camera.position.set(0, 1.1, 4.2);
      scene.add(new THREE.HemisphereLight("#D9E6FF", "#37285F", 2.2));
      const keyLight = new THREE.DirectionalLight("#FFF1CC", 2.4);
      keyLight.position.set(3, 4, 5);
      scene.add(keyLight);
      const rimLight = new THREE.PointLight("#477CFF", 1.8, 18);
      rimLight.position.set(-3, 1, -2);
      scene.add(rimLight);

      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(width, height);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.domElement.style.width = "100%";
      renderer.domElement.style.height = "100%";
      renderer.domElement.style.display = "block";
      host.replaceChildren(renderer.domElement);

      controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.target.set(0, 0.2, 0);
      controls.minDistance = 1;
      controls.maxDistance = 10;

      const resize = () => {
        if (!renderer || disposed) return;
        const nextWidth = Math.max(host.clientWidth, 260);
        const nextHeight = Math.max(host.clientHeight, 190);
        camera.aspect = nextWidth / nextHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(nextWidth, nextHeight);
      };
      window.addEventListener("resize", resize);

      const animate = () => {
        if (disposed || !renderer || !controls) return;
        controls.update();
        renderer.render(scene, camera);
        frame = window.requestAnimationFrame(animate);
      };
      animate();

      new GLTFLoader().load(
        uri,
        (gltf) => {
          if (disposed) return;
          model = gltf.scene;
          model.scale.setScalar(Math.min(Math.max(scale, 0.1), 4));
          model.rotation.set(
            (rotationX * Math.PI) / 180,
            (rotationY * Math.PI) / 180,
            (rotationZ * Math.PI) / 180,
          );
          scene.add(model);
          setStatus("ready");
        },
        undefined,
        (error) => {
          if (disposed) return;
          setStatus("error");
          setErrorMessage(
            error instanceof Error
              ? error.message
              : "The model could not be rendered. Confirm the asset is a valid GLB or self-contained glTF file.",
          );
        },
      );

      return () => {
        disposed = true;
        window.cancelAnimationFrame(frame);
        window.removeEventListener("resize", resize);
        controls?.dispose();
        if (model) {
          model.traverse((object) => {
            if (object instanceof THREE.Mesh) {
              object.geometry.dispose();
              const materials = Array.isArray(object.material) ? object.material : [object.material];
              materials.forEach((material) => material.dispose());
            }
          });
        }
        renderer?.dispose();
        host.replaceChildren();
      };
    } catch (error) {
      setStatus("error");
      setErrorMessage(
        error instanceof Error ? error.message : "WebGL is unavailable in this browser.",
      );
    }
  }, [uri, scale, rotationX, rotationY, rotationZ]);

  return (
    <div
      ref={hostRef}
      role="img"
      aria-label="Interactive 3D model preview. Drag to rotate and use the wheel to zoom."
      style={{
        height: 260,
        width: "100%",
        overflow: "hidden",
        borderRadius: 14,
        border: "1px solid rgba(157, 169, 203, 0.2)",
        background: "#0D1425",
        position: "relative",
      }}
    >
      {status !== "ready" ? (
        <div
          role="status"
          style={{
            position: "absolute",
            zIndex: 1,
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 18,
            color: status === "error" ? "#F17883" : "#A8B3CC",
            font: "12px Inter, sans-serif",
            textAlign: "center",
            pointerEvents: "none",
          }}
        >
          {status === "loading"
            ? "Loading model preview…"
            : errorMessage || "This asset format could not be previewed."}
        </div>
      ) : null}
    </div>
  );
}
