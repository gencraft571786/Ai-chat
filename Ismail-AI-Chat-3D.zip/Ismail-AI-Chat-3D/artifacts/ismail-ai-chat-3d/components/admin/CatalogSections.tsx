import { Feather } from "@expo/vector-icons";
import {
  getGetAdminFramesQueryKey,
  getGetAdminGiftsQueryKey,
  getGetAdminSettingsQueryKey,
  getGetAdminVipLevelsQueryKey,
  getGetPublicCatalogQueryKey,
  useCreateAdminFrame,
  useCreateAdminGift,
  useCreateAdminVipLevel,
  useDeleteAdminFrame,
  useDeleteAdminGift,
  useDeleteAdminVipLevel,
  useGetAdminAssets,
  useGetAdminFrames,
  useGetAdminGifts,
  useGetAdminSettings,
  useGetAdminVipLevels,
  useUpdateAdminFrame,
  useUpdateAdminGift,
  useUpdateAdminSettings,
  useUpdateAdminVipLevel,
} from "@workspace/api-client-react";
import type {
  AdminAsset,
  AppSettingsInput,
  Gift,
  GiftInput,
  ProfileFrame,
  ProfileFrameInput,
  VipLevel,
  VipLevelInput,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import React, { useEffect, useMemo, useState } from "react";
import { Alert, Platform, Pressable, ScrollView, Text, View } from "react-native";
import { AssetPicker, SignedAssetPreview } from "./AdminControls";
import {
  AdminButton,
  AdminCard,
  AdminField,
  AdminNotice,
  AdminPill,
  AdminSwitch,
  ADMIN_COLORS,
  formatDate,
} from "./shared";

const categories = [
  "Roses",
  "Diamonds",
  "Crowns",
  "Moons",
  "Cars",
  "Yachts",
  "Butterflies",
  "Magical Gifts",
  "Luxury Gifts",
  "Seasonal Gifts",
];
const frameCategories = ["Gold", "Diamond", "Rainbow", "Galaxy", "Ice", "Neon"];
const statuses = ["draft", "published", "archived"] as const;
type ContentStatus = (typeof statuses)[number];

function confirmAction(title: string, message: string, onConfirm: () => void) {
  if (Platform.OS === "web" && typeof window !== "undefined") {
    if (window.confirm(`${title}\n\n${message}`)) onConfirm();
    return;
  }
  Alert.alert(title, message, [
    { text: "Cancel", style: "cancel" },
    { text: "Continue", style: "destructive", onPress: onConfirm },
  ]);
}

function StatusChoices({
  value,
  onChange,
}: {
  value: ContentStatus;
  onChange: (value: ContentStatus) => void;
}) {
  return (
    <View style={{ gap: 8, marginBottom: 14 }}>
      <Text style={{ color: "#BDC5D7", fontSize: 12, fontWeight: "600" }}>Publication status</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
        {statuses.map((status) => (
          <AdminPill
            key={status}
            label={status[0].toUpperCase() + status.slice(1)}
            active={status === value}
            onPress={() => onChange(status)}
          />
        ))}
      </View>
    </View>
  );
}

function isImage(asset: AdminAsset) {
  return asset.contentType.startsWith("image/");
}
function isVisual(asset: AdminAsset) {
  return isImage(asset) || asset.contentType === "video/mp4";
}
function isModel(asset: AdminAsset) {
  return asset.contentType === "model/gltf-binary" || asset.contentType === "model/gltf+json";
}
function isAudio(asset: AdminAsset) {
  return asset.contentType.startsWith("audio/");
}

function newGiftDraft(): GiftInput {
  return {
    name: "",
    description: "",
    category: "Roses",
    price: 0,
    status: "draft",
    thumbnailAssetId: null,
    imageAssetId: null,
    modelAssetId: null,
    soundAssetId: null,
    animationType: "float",
    animationDurationMs: 1400,
    displayOrder: 0,
    effectConfig: {
      scale: 1,
      rotationX: 0,
      rotationY: 0,
      rotationZ: 0,
      lighting: "studio",
      particleEffect: "sparkle",
      glowColor: "#D8B55A",
      glowIntensity: 0.55,
      duration: 1400,
    },
  };
}

function giftDraftFromRecord(gift: Gift): GiftInput {
  return {
    name: gift.name,
    description: gift.description,
    category: gift.category,
    price: gift.price,
    status: gift.status,
    thumbnailAssetId: gift.thumbnailAssetId,
    imageAssetId: gift.imageAssetId,
    modelAssetId: gift.modelAssetId,
    soundAssetId: gift.soundAssetId,
    animationType: gift.animationType,
    animationDurationMs: gift.animationDurationMs,
    displayOrder: gift.displayOrder,
    effectConfig: gift.effectConfig,
  };
}

export function GiftManagementSection({ studio = false }: { studio?: boolean }) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const gifts = useGetAdminGifts({
    search: search || undefined,
    status: statusFilter || undefined,
  });
  const assets = useGetAdminAssets();
  const createGift = useCreateAdminGift();
  const updateGift = useUpdateAdminGift();
  const deleteGift = useDeleteAdminGift();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<Gift | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState<GiftInput>(newGiftDraft());
  const [error, setError] = useState("");
  const assetRows = assets.data ?? [];
  const selectedModel = assetRows.find((asset) => asset.id === draft.modelAssetId);
  const selectedThumbnail = assetRows.find(
    (asset) => asset.id === (draft.thumbnailAssetId ?? draft.imageAssetId),
  );

  useEffect(() => {
    setDraft(editing ? giftDraftFromRecord(editing) : newGiftDraft());
    setError("");
  }, [editing?.id, creating]);

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: getGetAdminGiftsQueryKey() });
    await gifts.refetch();
  };

  const save = async () => {
    setError("");
    try {
      if (editing) {
        await updateGift.mutateAsync({ id: editing.id, data: draft });
      } else {
        await createGift.mutateAsync({ data: draft });
      }
      setEditing(null);
      setCreating(false);
      await invalidate();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Gift changes were not saved.");
    }
  };

  const updateStatus = (gift: Gift, nextStatus: ContentStatus) => {
    const action =
      nextStatus === "published"
        ? "Publish this gift?"
        : nextStatus === "archived"
          ? "Archive this gift?"
          : "Unpublish this gift?";
    confirmAction(action, "This changes the published catalog state.", () => {
      setError("");
      updateGift.mutate(
        { id: gift.id, data: { status: nextStatus } },
        {
          onSuccess: () => void invalidate(),
          onError: (caught) => setError(caught instanceof Error ? caught.message : "Status update failed."),
        },
      );
    });
  };

  const remove = (gift: Gift) =>
    confirmAction("Delete gift?", `Permanently delete ${gift.name}?`, () => {
      setError("");
      deleteGift.mutate(
        { id: gift.id },
        {
          onSuccess: () => void invalidate(),
          onError: (caught) => setError(caught instanceof Error ? caught.message : "Gift deletion failed."),
        },
      );
    });

  const patchDraft = <K extends keyof GiftInput>(key: K, value: GiftInput[K]) =>
    setDraft((current) => ({ ...current, [key]: value }));
  const patchEffect = (key: string, value: string | number) =>
    setDraft((current) => ({
      ...current,
      effectConfig: { ...current.effectConfig, [key]: value },
    }));

  return (
    <View style={{ gap: 14 }}>
      <AdminCard
        title={studio ? "3D Gift Studio" : "Gift catalog"}
        subtitle={
          studio
            ? "Upload and inspect GLB or self-contained glTF models, then save scale, orientation, lighting and effects with the gift."
            : "Create, review and publish the gift catalog. Prices are catalog display values; this app has no connected checkout or balance service."
        }
      >
        {!creating && !editing ? (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 9 }}>
            <AdminButton
              label={studio ? "Configure a 3D gift" : "Add gift"}
              icon="plus"
              onPress={() => {
                setEditing(null);
                setCreating(true);
              }}
            />
            <AdminButton
              label="Open asset library"
              icon="box"
              kind="secondary"
              onPress={() => {
                setError("Upload model, image and sound assets from the Asset Library section, then return to this editor.");
              }}
            />
          </View>
        ) : null}

        {creating || editing ? (
          <View style={{ gap: 4, marginTop: 14 }}>
            <Text style={{ color: ADMIN_COLORS.gold, fontSize: 13, fontWeight: "700", marginBottom: 8 }}>
              {editing ? `Editing ${editing.name}` : "New gift"}
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              <AdminField label="Gift name" value={draft.name} onChangeText={(value) => patchDraft("name", value)} placeholder="Golden rose" />
              <AdminField label="Category" value={draft.category} onChangeText={(value) => patchDraft("category", value)} placeholder="Roses" />
              <AdminField
                label="Catalog price"
                value={String(draft.price)}
                onChangeText={(value) => patchDraft("price", Math.max(0, Number.parseInt(value || "0", 10) || 0))}
                keyboardType="number-pad"
              />
              <AdminField
                label="Display order"
                value={String(draft.displayOrder ?? 0)}
                onChangeText={(value) => patchDraft("displayOrder", Math.max(0, Number.parseInt(value || "0", 10) || 0))}
                keyboardType="number-pad"
              />
            </View>
            <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, marginBottom: 10 }}>
              Suggested categories: {categories.join(", ")}.
            </Text>
            <AdminField
              label="Description"
              value={draft.description ?? ""}
              onChangeText={(value) => patchDraft("description", value)}
              placeholder="A short catalog description"
              multiline
            />
            <StatusChoices value={(draft.status ?? "draft") as ContentStatus} onChange={(value) => patchDraft("status", value)} />
            {!studio ? (
              <>
                <AssetPicker label="Thumbnail" assetId={draft.thumbnailAssetId ?? null} onChange={(value) => patchDraft("thumbnailAssetId", value)} assets={assetRows} filter={isImage} />
                <AssetPicker label="Main gift image or animation" assetId={draft.imageAssetId ?? null} onChange={(value) => patchDraft("imageAssetId", value)} assets={assetRows} filter={isVisual} />
                <AssetPicker label="3D model" assetId={draft.modelAssetId ?? null} onChange={(value) => patchDraft("modelAssetId", value)} assets={assetRows} filter={isModel} />
                <AssetPicker label="Sound effect" assetId={draft.soundAssetId ?? null} onChange={(value) => patchDraft("soundAssetId", value)} assets={assetRows} filter={isAudio} />
              </>
            ) : (
              <>
                <AssetPicker label="GLB or self-contained glTF model" assetId={draft.modelAssetId ?? null} onChange={(value) => patchDraft("modelAssetId", value)} assets={assetRows} filter={isModel} />
                {selectedModel ? (
                  <SignedAssetPreview
                    assetId={selectedModel.id}
                    asset={selectedModel}
                    scale={Number(draft.effectConfig?.scale ?? 1)}
                    rotationX={Number(draft.effectConfig?.rotationX ?? 0)}
                    rotationY={Number(draft.effectConfig?.rotationY ?? 0)}
                    rotationZ={Number(draft.effectConfig?.rotationZ ?? 0)}
                  />
                ) : null}
              </>
            )}
            {selectedThumbnail && !studio ? (
              <SignedAssetPreview assetId={selectedThumbnail.id} asset={selectedThumbnail} />
            ) : null}
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10, marginTop: 12 }}>
              <AdminField
                label="Entrance animation"
                value={draft.animationType ?? "float"}
                onChangeText={(value) => patchDraft("animationType", value)}
                placeholder="float, burst, orbit…"
              />
              <AdminField
                label="Animation duration (ms)"
                value={String(draft.animationDurationMs ?? 1400)}
                onChangeText={(value) => patchDraft("animationDurationMs", Math.max(0, Number.parseInt(value || "0", 10) || 0))}
                keyboardType="number-pad"
              />
            </View>
            {studio ? (
              <>
                <Text style={{ color: ADMIN_COLORS.gold, fontSize: 13, fontWeight: "700", marginTop: 6, marginBottom: 8 }}>
                  Model presentation
                </Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
                  {[
                    ["Scale", "scale", "1"],
                    ["Rotate X°", "rotationX", "0"],
                    ["Rotate Y°", "rotationY", "0"],
                    ["Rotate Z°", "rotationZ", "0"],
                    ["Glow intensity 0–1", "glowIntensity", "0.55"],
                  ].map(([label, key, fallback]) => (
                    <AdminField
                      key={key}
                      label={label}
                      value={String(draft.effectConfig?.[key] ?? fallback)}
                      onChangeText={(value) => patchEffect(key, Number.parseFloat(value) || 0)}
                      keyboardType="decimal-pad"
                    />
                  ))}
                  <AdminField
                    label="Glow color"
                    value={String(draft.effectConfig?.glowColor ?? "#D8B55A")}
                    onChangeText={(value) => patchEffect("glowColor", value)}
                    autoCapitalize="characters"
                  />
                  <AdminField
                    label="Lighting preset"
                    value={String(draft.effectConfig?.lighting ?? "studio")}
                    onChangeText={(value) => patchEffect("lighting", value)}
                    placeholder="studio, warm, cool, neon"
                  />
                  <AdminField
                    label="Particle effect"
                    value={String(draft.effectConfig?.particleEffect ?? "sparkle")}
                    onChangeText={(value) => patchEffect("particleEffect", value)}
                    placeholder="none, sparkle, trail, burst"
                  />
                </View>
                <AdminNotice message="The browser preview renders the actual model and supports drag-to-rotate and zoom. Android can edit and save these settings, but the current native app renderer does not preview 3D models." />
              </>
            ) : null}
            {error ? <AdminNotice kind="error" message={error} /> : null}
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
              <AdminButton
                label={createGift.isPending || updateGift.isPending ? "Saving…" : editing ? "Save changes" : "Create gift"}
                icon="save"
                onPress={() => void save()}
                disabled={!draft.name.trim() || !draft.category.trim() || createGift.isPending || updateGift.isPending}
              />
              <AdminButton
                label="Cancel"
                kind="quiet"
                onPress={() => {
                  setCreating(false);
                  setEditing(null);
                }}
              />
            </View>
          </View>
        ) : null}
      </AdminCard>

      <AdminCard title="Browse gifts">
        <AdminField label="Search gifts" value={search} onChangeText={setSearch} placeholder="Name or category" autoCapitalize="none" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, marginBottom: 12 }}>
          <AdminPill label="All" active={!statusFilter} onPress={() => setStatusFilter("")} />
          {statuses.map((status) => (
            <AdminPill key={status} label={status} active={statusFilter === status} onPress={() => setStatusFilter(status)} />
          ))}
        </ScrollView>
        {gifts.isLoading ? <Text style={{ color: ADMIN_COLORS.muted }}>Loading gift records…</Text> : null}
        {gifts.isError ? <AdminNotice kind="error" message="Gift records could not be loaded." /> : null}
        {!gifts.isLoading && !gifts.isError && (gifts.data?.length ?? 0) === 0 ? (
          <Text style={{ color: ADMIN_COLORS.muted, fontSize: 13 }}>No matching gifts. Add one above to begin.</Text>
        ) : null}
        <View style={{ gap: 9 }}>
          {(gifts.data ?? []).map((gift) => (
            <View
              key={gift.id}
              style={{
                borderRadius: 14,
                borderWidth: 1,
                borderColor: ADMIN_COLORS.border,
                backgroundColor: "rgba(8, 12, 24, 0.55)",
                padding: 13,
                gap: 9,
              }}
            >
              <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: ADMIN_COLORS.text, fontSize: 14, fontWeight: "700" }}>{gift.name}</Text>
                  <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, marginTop: 4 }}>
                    {gift.category} · {gift.price} catalog credits · order {gift.displayOrder}
                  </Text>
                </View>
                <AdminPill label={gift.status} active={gift.status === "published"} />
              </View>
              {gift.description ? (
                <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12 }}>{gift.description}</Text>
              ) : null}
              <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11 }}>
                Updated {formatDate(gift.updatedAt)} · {gift.modelAssetId ? "3D model attached" : "No 3D model"}
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7 }}>
                <AdminButton
                  label="Edit"
                  compact
                  kind="secondary"
                  icon="edit-2"
                  onPress={() => {
                    setCreating(false);
                    setEditing(gift);
                  }}
                />
                <AdminButton
                  label={gift.status === "published" ? "Unpublish" : "Publish"}
                  compact
                  icon={gift.status === "published" ? "eye-off" : "globe"}
                  disabled={gift.status === "archived"}
                  onPress={() => updateStatus(gift, gift.status === "published" ? "draft" : "published")}
                />
                {gift.status !== "archived" ? (
                  <AdminButton label="Archive" compact kind="quiet" icon="archive" onPress={() => updateStatus(gift, "archived")} />
                ) : null}
                {gift.status !== "published" ? (
                  <AdminButton label="Delete" compact kind="danger" icon="trash-2" onPress={() => remove(gift)} />
                ) : null}
              </View>
            </View>
          ))}
        </View>
      </AdminCard>
    </View>
  );
}

function frameDraftFromRecord(frame: ProfileFrame): ProfileFrameInput {
  return {
    name: frame.name,
    description: frame.description,
    category: frame.category,
    status: frame.status,
    assetId: frame.assetId,
    vipLevelRequired: frame.vipLevelRequired,
    unlockCondition: frame.unlockCondition,
    effects: frame.effects,
  };
}

function newFrameDraft(): ProfileFrameInput {
  return {
    name: "",
    description: "",
    category: "Gold",
    status: "draft",
    assetId: null,
    vipLevelRequired: null,
    unlockCondition: null,
    effects: {
      glowColor: "#D8B55A",
      glowIntensity: 0.65,
      rotationY: 0,
      particleEffect: "sparkle",
    },
  };
}

function FrameSample({ assetId, asset, effects }: { assetId: string | null; asset?: AdminAsset; effects: Record<string, unknown> }) {
  const query = useGetAdminAssetPreviewUrl(assetId ?? "", {
    query: { enabled: Boolean(assetId && asset?.contentType.startsWith("image/")), retry: false },
  });
  const glow = typeof effects.glowColor === "string" ? effects.glowColor : ADMIN_COLORS.gold;
  const angle = Number(effects.rotationY ?? 0);
  return (
    <View style={{ alignItems: "center", gap: 8, paddingVertical: 8 }}>
      <View
        style={{
          width: 106,
          height: 106,
          borderRadius: 60,
          borderWidth: 5,
          borderColor: glow,
          backgroundColor: "#0B1020",
          alignItems: "center",
          justifyContent: "center",
          shadowColor: glow,
          shadowOpacity: Math.max(0.05, Math.min(0.8, Number(effects.glowIntensity ?? 0.5))),
          shadowRadius: 18,
          elevation: 5,
          transform: [{ rotate: `${angle}deg` }],
          overflow: "hidden",
        }}
      >
        <Feather name="user" size={36} color="#AEBAD3" />
        {query.data?.url ? (
          <Image
            source={{ uri: query.data.url }}
            contentFit="contain"
            accessibilityLabel="Frame asset layered around a sample profile"
            style={{ position: "absolute", width: 108, height: 108 }}
          />
        ) : null}
      </View>
      <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11 }}>Sample profile preview</Text>
      {asset && !asset.contentType.startsWith("image/") ? (
        <Text style={{ color: ADMIN_COLORS.muted, fontSize: 10, textAlign: "center" }}>
          Animated file saved; overlay preview is for still images.
        </Text>
      ) : null}
    </View>
  );
}

export function ProfileFramesSection() {
  const frames = useGetAdminFrames();
  const assets = useGetAdminAssets();
  const createFrame = useCreateAdminFrame();
  const updateFrame = useUpdateAdminFrame();
  const deleteFrame = useDeleteAdminFrame();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<ProfileFrame | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState<ProfileFrameInput>(newFrameDraft());
  const [error, setError] = useState("");
  const assetRows = assets.data ?? [];
  const frameAsset = assetRows.find((asset) => asset.id === draft.assetId);

  useEffect(() => {
    setDraft(editing ? frameDraftFromRecord(editing) : newFrameDraft());
    setError("");
  }, [editing?.id, creating]);

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: getGetAdminFramesQueryKey() });
    await frames.refetch();
  };
  const patchEffect = (key: string, value: string | number) =>
    setDraft((current) => ({ ...current, effects: { ...current.effects, [key]: value } }));
  const save = async () => {
    setError("");
    try {
      if (editing) await updateFrame.mutateAsync({ id: editing.id, data: draft });
      else await createFrame.mutateAsync({ data: draft });
      setEditing(null);
      setCreating(false);
      await refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Frame changes were not saved.");
    }
  };
  const changeStatus = (frame: ProfileFrame, next: ContentStatus) =>
    confirmAction(
      next === "published" ? "Publish frame?" : next === "archived" ? "Archive frame?" : "Unpublish frame?",
      "This updates the public profile-frame catalog.",
      () =>
        updateFrame.mutate(
          { id: frame.id, data: { status: next } },
          {
            onSuccess: () => void refresh(),
            onError: (caught) => setError(caught instanceof Error ? caught.message : "Frame status update failed."),
          },
        ),
    );
  const remove = (frame: ProfileFrame) =>
    confirmAction("Delete frame?", `Permanently delete ${frame.name}?`, () =>
      deleteFrame.mutate(
        { id: frame.id },
        {
          onSuccess: () => void refresh(),
          onError: (caught) => setError(caught instanceof Error ? caught.message : "Frame deletion failed."),
        },
      ),
    );

  return (
    <View style={{ gap: 14 }}>
      <AdminCard title="Profile frame collection" subtitle="Frames are layered around profile imagery; uploaded photos remain unchanged.">
        {!creating && !editing ? (
          <AdminButton label="Create frame" icon="plus" onPress={() => setCreating(true)} />
        ) : null}
        {creating || editing ? (
          <View style={{ gap: 4, marginTop: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              <AdminField label="Frame name" value={draft.name} onChangeText={(value) => setDraft((current) => ({ ...current, name: value }))} placeholder="Aurora Gold" />
              <AdminField label="Category" value={draft.category} onChangeText={(value) => setDraft((current) => ({ ...current, category: value }))} placeholder="Gold, diamond, galaxy…" />
            </View>
            <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, marginBottom: 10 }}>
              Premium categories: {frameCategories.join(", ")}.
            </Text>
            <AdminField label="Description" value={draft.description ?? ""} onChangeText={(value) => setDraft((current) => ({ ...current, description: value }))} placeholder="Frame description" multiline />
            <StatusChoices value={(draft.status ?? "draft") as ContentStatus} onChange={(value) => setDraft((current) => ({ ...current, status: value }))} />
            <AssetPicker label="Frame image or animation" assetId={draft.assetId ?? null} onChange={(value) => setDraft((current) => ({ ...current, assetId: value }))} assets={assetRows} filter={isVisual} />
            {frameAsset ? <FrameSample assetId={frameAsset.id} asset={frameAsset} effects={draft.effects ?? {}} /> : null}
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              <AdminField label="VIP level requirement" value={draft.vipLevelRequired ?? ""} onChangeText={(value) => setDraft((current) => ({ ...current, vipLevelRequired: value || null }))} placeholder="Optional level name" />
              <AdminField label="Unlock condition" value={draft.unlockCondition ?? ""} onChangeText={(value) => setDraft((current) => ({ ...current, unlockCondition: value || null }))} placeholder="Optional" />
              <AdminField label="Glow color" value={String(draft.effects?.glowColor ?? "#D8B55A")} onChangeText={(value) => patchEffect("glowColor", value)} autoCapitalize="characters" />
              <AdminField label="Glow intensity 0–1" value={String(draft.effects?.glowIntensity ?? 0.65)} onChangeText={(value) => patchEffect("glowIntensity", Number.parseFloat(value) || 0)} keyboardType="decimal-pad" />
              <AdminField label="Rotation (degrees)" value={String(draft.effects?.rotationY ?? 0)} onChangeText={(value) => patchEffect("rotationY", Number.parseFloat(value) || 0)} keyboardType="decimal-pad" />
              <AdminField label="Sparkle effect" value={String(draft.effects?.particleEffect ?? "sparkle")} onChangeText={(value) => patchEffect("particleEffect", value)} placeholder="none, sparkle, glow" />
            </View>
            <AdminNotice message="Static frame artwork is previewed around a sample profile. Rotation and sparkle metadata are saved, but continuous animation is not yet implemented in the existing app renderer." />
            {error ? <AdminNotice kind="error" message={error} /> : null}
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
              <AdminButton label={createFrame.isPending || updateFrame.isPending ? "Saving…" : editing ? "Save changes" : "Create frame"} icon="save" onPress={() => void save()} disabled={!draft.name.trim() || !draft.category.trim() || createFrame.isPending || updateFrame.isPending} />
              <AdminButton label="Cancel" kind="quiet" onPress={() => { setCreating(false); setEditing(null); }} />
            </View>
          </View>
        ) : null}
      </AdminCard>
      {frames.isError ? <AdminNotice kind="error" message="Profile frame records could not be loaded." /> : null}
      {(frames.data ?? []).map((frame) => (
        <AdminCard key={frame.id}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 10 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: ADMIN_COLORS.text, fontWeight: "700" }}>{frame.name}</Text>
              <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, marginTop: 4 }}>{frame.category} · {frame.vipLevelRequired || "No VIP requirement"}</Text>
            </View>
            <AdminPill label={frame.status} active={frame.status === "published"} />
          </View>
          {frame.description ? <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12, marginTop: 8 }}>{frame.description}</Text> : null}
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 12 }}>
            <AdminButton label="Edit" kind="secondary" compact icon="edit-2" onPress={() => { setCreating(false); setEditing(frame); }} />
            <AdminButton label={frame.status === "published" ? "Unpublish" : "Publish"} compact icon="globe" disabled={frame.status === "archived"} onPress={() => changeStatus(frame, frame.status === "published" ? "draft" : "published")} />
            {frame.status !== "archived" ? <AdminButton label="Archive" compact kind="quiet" icon="archive" onPress={() => changeStatus(frame, "archived")} /> : null}
            {frame.status !== "published" ? <AdminButton label="Delete" compact kind="danger" icon="trash-2" onPress={() => remove(frame)} /> : null}
          </View>
        </AdminCard>
      ))}
      {!frames.isLoading && !frames.isError && (frames.data?.length ?? 0) === 0 ? (
        <AdminCard title="No profile frames">
          <Text style={{ color: ADMIN_COLORS.muted, fontSize: 13 }}>Create frames and upload artwork to publish them in the app.</Text>
        </AdminCard>
      ) : null}
    </View>
  );
}

function newVipDraft(): VipLevelInput {
  return {
    level: 1,
    name: "",
    description: "",
    badgeAssetId: null,
    membershipDescription: "",
    unlockCondition: "",
    isActive: true,
    displayOrder: 0,
  };
}

function vipDraftFromRecord(vip: VipLevel): VipLevelInput {
  return {
    level: vip.level,
    name: vip.name,
    description: vip.description,
    badgeAssetId: vip.badgeAssetId,
    membershipDescription: vip.membershipDescription,
    unlockCondition: vip.unlockCondition,
    isActive: vip.isActive,
    displayOrder: vip.displayOrder,
  };
}

export function VipCatalogSection() {
  const levels = useGetAdminVipLevels();
  const assets = useGetAdminAssets();
  const createLevel = useCreateAdminVipLevel();
  const updateLevel = useUpdateAdminVipLevel();
  const deleteLevel = useDeleteAdminVipLevel();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<VipLevel | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState<VipLevelInput>(newVipDraft());
  const [error, setError] = useState("");
  const assetRows = assets.data ?? [];
  useEffect(() => {
    setDraft(editing ? vipDraftFromRecord(editing) : newVipDraft());
    setError("");
  }, [editing?.id, creating]);
  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: getGetAdminVipLevelsQueryKey() });
    await levels.refetch();
  };
  const save = async () => {
    setError("");
    try {
      if (editing) await updateLevel.mutateAsync({ id: editing.id, data: draft });
      else await createLevel.mutateAsync({ data: draft });
      setEditing(null);
      setCreating(false);
      await refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "VIP level changes were not saved.");
    }
  };
  const remove = (level: VipLevel) =>
    confirmAction("Delete VIP level?", `Permanently delete ${level.name}?`, () =>
      deleteLevel.mutate(
        { id: level.id },
        {
          onSuccess: () => void refresh(),
          onError: (caught) => setError(caught instanceof Error ? caught.message : "VIP level deletion failed."),
        },
      ),
    );
  return (
    <View style={{ gap: 14 }}>
      <AdminCard title="VIP levels and catalog visibility" subtitle="Define membership labels, badges and unlock text. No payment or virtual-balance service is connected, so these settings do not grant purchases or alter balances.">
        {!creating && !editing ? <AdminButton label="Add VIP level" icon="plus" onPress={() => setCreating(true)} /> : null}
        {creating || editing ? (
          <View style={{ marginTop: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              <AdminField label="Level number" value={String(draft.level)} onChangeText={(value) => setDraft((current) => ({ ...current, level: Math.max(1, Number.parseInt(value || "1", 10) || 1) }))} keyboardType="number-pad" />
              <AdminField label="Name" value={draft.name} onChangeText={(value) => setDraft((current) => ({ ...current, name: value }))} placeholder="Gold VIP" />
              <AdminField label="Display order" value={String(draft.displayOrder ?? 0)} onChangeText={(value) => setDraft((current) => ({ ...current, displayOrder: Math.max(0, Number.parseInt(value || "0", 10) || 0) }))} keyboardType="number-pad" />
            </View>
            <AdminField label="Short description" value={draft.description ?? ""} onChangeText={(value) => setDraft((current) => ({ ...current, description: value }))} multiline />
            <AdminField label="Membership description" value={draft.membershipDescription ?? ""} onChangeText={(value) => setDraft((current) => ({ ...current, membershipDescription: value }))} multiline />
            <AdminField label="Unlock condition" value={draft.unlockCondition ?? ""} onChangeText={(value) => setDraft((current) => ({ ...current, unlockCondition: value }))} placeholder="Informational condition only" />
            <AssetPicker label="VIP badge" assetId={draft.badgeAssetId ?? null} onChange={(value) => setDraft((current) => ({ ...current, badgeAssetId: value }))} assets={assetRows} filter={isImage} />
            <AdminSwitch label="Visible in the public VIP catalog" value={draft.isActive ?? true} onValueChange={(value) => setDraft((current) => ({ ...current, isActive: value }))} />
            {error ? <View style={{ marginVertical: 8 }}><AdminNotice kind="error" message={error} /></View> : null}
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 12 }}>
              <AdminButton label={createLevel.isPending || updateLevel.isPending ? "Saving…" : editing ? "Save changes" : "Create VIP level"} icon="save" onPress={() => void save()} disabled={!draft.name.trim() || createLevel.isPending || updateLevel.isPending} />
              <AdminButton label="Cancel" kind="quiet" onPress={() => { setCreating(false); setEditing(null); }} />
            </View>
          </View>
        ) : null}
      </AdminCard>
      {levels.isError ? <AdminNotice kind="error" message="VIP levels could not be loaded." /> : null}
      {(levels.data ?? []).map((level) => (
        <AdminCard key={level.id}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 10 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: ADMIN_COLORS.text, fontWeight: "700" }}>VIP {level.level} · {level.name}</Text>
              <Text style={{ color: ADMIN_COLORS.muted, fontSize: 11, marginTop: 4 }}>{level.isActive ? "Visible" : "Hidden"} · display order {level.displayOrder}</Text>
            </View>
            <AdminPill label={level.isActive ? "Active" : "Hidden"} active={level.isActive} />
          </View>
          {level.description ? <Text style={{ color: ADMIN_COLORS.muted, fontSize: 12, marginTop: 8 }}>{level.description}</Text> : null}
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 12 }}>
            <AdminButton label="Edit" kind="secondary" compact icon="edit-2" onPress={() => { setCreating(false); setEditing(level); }} />
            <AdminButton
              label={level.isActive ? "Hide" : "Show"}
              compact
              icon={level.isActive ? "eye-off" : "eye"}
              onPress={() => updateLevel.mutate({ id: level.id, data: { isActive: !level.isActive } }, { onSuccess: () => void refresh() })}
            />
            <AdminButton label="Delete" compact kind="danger" icon="trash-2" onPress={() => remove(level)} />
          </View>
        </AdminCard>
      ))}
      {!levels.isLoading && !levels.isError && (levels.data?.length ?? 0) === 0 ? (
        <AdminCard title="No VIP levels"><Text style={{ color: ADMIN_COLORS.muted, fontSize: 13 }}>Create a level to manage badges and informational unlock conditions.</Text></AdminCard>
      ) : null}
    </View>
  );
}

const defaultTheme = {
  background: "#080B16",
  surface: "#111626",
  primary: "#7958F5",
  secondary: "#288EFF",
  accent: "#D8B55A",
};
const defaultCatalogAppearance = { layout: "grid" as const, showPrices: true, title: "Made to be sent" };

export function AppearanceSection() {
  const settings = useGetAdminSettings();
  const assets = useGetAdminAssets();
  const updateSettings = useUpdateAdminSettings();
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState<AppSettingsInput>({
    theme: defaultTheme,
    catalogAppearance: defaultCatalogAppearance,
    bannerText: "",
    bannerAssetId: null,
    effectsEnabled: true,
  });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const assetRows = assets.data ?? [];
  const bannerAsset = assetRows.find((asset) => asset.id === draft.bannerAssetId);
  useEffect(() => {
    if (!settings.data) return;
    setDraft({
      theme: settings.data.theme,
      catalogAppearance: settings.data.catalogAppearance,
      bannerText: settings.data.bannerText,
      bannerAssetId: settings.data.bannerAssetId,
      effectsEnabled: settings.data.effectsEnabled,
    });
  }, [settings.dataUpdatedAt]);

  const updateTheme = (key: keyof typeof defaultTheme, value: string) =>
    setDraft((current) => ({
      ...current,
      theme: { ...defaultTheme, ...current.theme, [key]: value },
    }));
  const save = async () => {
    setMessage("");
    setError("");
    try {
      const saved = await updateSettings.mutateAsync({ data: draft });
      setDraft({
        theme: saved.theme,
        catalogAppearance: saved.catalogAppearance,
        bannerText: saved.bannerText,
        bannerAssetId: saved.bannerAssetId,
        effectsEnabled: saved.effectsEnabled,
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getGetAdminSettingsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetPublicCatalogQueryKey() }),
      ]);
      setMessage("App appearance settings were saved.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Appearance settings were not saved.");
    }
  };
  const theme = { ...defaultTheme, ...draft.theme };
  const appearance = { ...defaultCatalogAppearance, ...draft.catalogAppearance };

  return (
    <View style={{ gap: 14 }}>
      <AdminCard title="App appearance" subtitle="Changes persist in the database and are served to the mobile app. The existing app applies its background, surface, primary, secondary glow and accent tokens on refresh.">
        {settings.isLoading ? <Text style={{ color: ADMIN_COLORS.muted }}>Loading saved appearance…</Text> : null}
        {settings.isError ? <AdminNotice kind="error" message="Saved settings could not be loaded. Editing is still possible, but a save will only be confirmed by the server response." /> : null}
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          <AdminField label="Background color" value={theme.background} onChangeText={(value) => updateTheme("background", value)} autoCapitalize="characters" />
          <AdminField label="Surface color" value={theme.surface} onChangeText={(value) => updateTheme("surface", value)} autoCapitalize="characters" />
          <AdminField label="Primary color" value={theme.primary} onChangeText={(value) => updateTheme("primary", value)} autoCapitalize="characters" />
          <AdminField label="Secondary glow color" value={theme.secondary} onChangeText={(value) => updateTheme("secondary", value)} autoCapitalize="characters" />
          <AdminField label="Accent color" value={theme.accent} onChangeText={(value) => updateTheme("accent", value)} autoCapitalize="characters" />
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
          {Object.entries(theme).map(([label, color]) => (
            <View key={label} style={{ width: 88, gap: 5, alignItems: "center" }}>
              <View style={{ height: 38, width: 70, borderRadius: 10, borderWidth: 1, borderColor: ADMIN_COLORS.border, backgroundColor: color }} />
              <Text style={{ color: ADMIN_COLORS.muted, fontSize: 10 }}>{label}</Text>
            </View>
          ))}
        </View>
        <AdminField label="App banner text" value={draft.bannerText ?? ""} onChangeText={(value) => setDraft((current) => ({ ...current, bannerText: value }))} placeholder="Optional announcement" />
        <AssetPicker label="App banner image or video" assetId={draft.bannerAssetId ?? null} onChange={(value) => setDraft((current) => ({ ...current, bannerAssetId: value }))} assets={assetRows} filter={isVisual} />
        {bannerAsset ? <SignedAssetPreview assetId={bannerAsset.id} asset={bannerAsset} /> : null}
        <AdminSwitch
          label="Enable supported interface effects"
          description="Turns on the app's existing motion and glow treatment where supported."
          value={draft.effectsEnabled ?? true}
          onValueChange={(value) => setDraft((current) => ({ ...current, effectsEnabled: value }))}
        />
      </AdminCard>

      <AdminCard title="Gift catalog appearance" subtitle="Display options for the public catalog. Gift prices are informational until a payment and balance service is connected.">
        <AdminField label="Catalog heading" value={appearance.title} onChangeText={(value) => setDraft((current) => ({ ...current, catalogAppearance: { ...appearance, title: value } }))} placeholder="Made to be sent" />
        <View style={{ gap: 8, marginBottom: 12 }}>
          <Text style={{ color: "#BDC5D7", fontSize: 12, fontWeight: "600" }}>Catalog layout</Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <AdminPill label="Grid" active={appearance.layout === "grid"} onPress={() => setDraft((current) => ({ ...current, catalogAppearance: { ...appearance, layout: "grid" } }))} />
            <AdminPill label="List" active={appearance.layout === "list"} onPress={() => setDraft((current) => ({ ...current, catalogAppearance: { ...appearance, layout: "list" } }))} />
          </View>
        </View>
        <AdminSwitch label="Show catalog prices" value={appearance.showPrices} onValueChange={(value) => setDraft((current) => ({ ...current, catalogAppearance: { ...appearance, showPrices: value } }))} />
        <View style={{ marginTop: 14 }}>
          <LinearGradient colors={[theme.background, theme.surface, theme.secondary]} style={{ minHeight: 106, borderRadius: 16, padding: 18, justifyContent: "space-between" }}>
            <Text style={{ color: theme.accent, fontSize: 10, fontWeight: "800", letterSpacing: 1.5 }}>THEME PREVIEW</Text>
            <Text style={{ color: "#F6F2E8", fontSize: 20, fontWeight: "800" }}>{appearance.title || "Gift catalog"}</Text>
            <Text style={{ color: "#C5CEE3", fontSize: 12 }}>{draft.bannerText || "Your app banner will appear here."}</Text>
          </LinearGradient>
        </View>
        {message ? <View style={{ marginTop: 12 }}><AdminNotice kind="success" message={message} /></View> : null}
        {error ? <View style={{ marginTop: 12 }}><AdminNotice kind="error" message={error} /></View> : null}
        <View style={{ marginTop: 14 }}>
          <AdminButton label={updateSettings.isPending ? "Saving…" : "Save app appearance"} icon="save" onPress={() => void save()} disabled={updateSettings.isPending} />
        </View>
      </AdminCard>
    </View>
  );
}

