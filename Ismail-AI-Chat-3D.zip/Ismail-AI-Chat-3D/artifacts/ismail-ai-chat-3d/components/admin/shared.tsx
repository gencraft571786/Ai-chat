import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
  type TextInputProps,
  type ViewStyle,
} from "react-native";

export const ADMIN_COLORS = {
  background: "#080B16",
  panel: "#11182A",
  panelLight: "#17213A",
  border: "rgba(157, 169, 203, 0.18)",
  text: "#F5F4FB",
  muted: "#929DB5",
  purple: "#8567FF",
  blue: "#3198FF",
  gold: "#D8B55A",
  green: "#56D1A0",
  red: "#F17883",
};

export function AdminCard({
  children,
  title,
  subtitle,
  style,
}: {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  style?: ViewStyle;
}) {
  return (
    <LinearGradient
      colors={["rgba(25, 34, 58, 0.96)", "rgba(14, 19, 34, 0.96)"]}
      start={{ x: 0.05, y: 0 }}
      end={{ x: 0.9, y: 1 }}
      style={[styles.card, style]}
    >
      {(title || subtitle) && (
        <View style={styles.cardHeading}>
          {title ? <Text style={styles.cardTitle}>{title}</Text> : null}
          {subtitle ? <Text style={styles.cardSubtitle}>{subtitle}</Text> : null}
        </View>
      )}
      {children}
    </LinearGradient>
  );
}

export function AdminButton({
  label,
  onPress,
  kind = "primary",
  disabled = false,
  icon,
  compact = false,
}: {
  label: string;
  onPress: () => void;
  kind?: "primary" | "secondary" | "danger" | "quiet";
  disabled?: boolean;
  icon?: keyof typeof Feather.glyphMap;
  compact?: boolean;
}) {
  const background =
    kind === "primary"
      ? [ADMIN_COLORS.purple, "#5B72F1"]
      : kind === "danger"
        ? ["#9E394D", "#7C2E43"]
        : kind === "secondary"
          ? ["#24314B", "#1B2640"]
          : ["transparent", "transparent"];
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.buttonOuter,
        disabled && styles.disabled,
        pressed && !disabled && styles.pressed,
      ]}
    >
      <LinearGradient
        colors={background}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.button, compact && styles.buttonCompact, kind === "quiet" && styles.quietButton]}
      >
        {icon ? (
          <Feather
            name={icon}
            size={15}
            color={kind === "quiet" ? ADMIN_COLORS.muted : ADMIN_COLORS.text}
          />
        ) : null}
        <Text style={[styles.buttonText, kind === "quiet" && styles.quietText]}>
          {label}
        </Text>
      </LinearGradient>
    </Pressable>
  );
}

export function AdminField({
  label,
  value,
  onChangeText,
  placeholder,
  multiline = false,
  keyboardType = "default",
  autoCapitalize = "sentences",
  secureTextEntry,
  editable = true,
  ...inputProps
}: TextInputProps & {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        {...inputProps}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#737E97"
        multiline={multiline}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize}
        secureTextEntry={secureTextEntry}
        editable={editable}
        selectionColor={ADMIN_COLORS.blue}
        style={[styles.input, multiline && styles.multiline]}
      />
    </View>
  );
}

export function AdminSwitch({
  label,
  description,
  value,
  onValueChange,
}: {
  label: string;
  description?: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}) {
  return (
    <View style={styles.switchRow}>
      <View style={styles.switchCopy}>
        <Text style={styles.switchTitle}>{label}</Text>
        {description ? <Text style={styles.switchDescription}>{description}</Text> : null}
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: "#353F56", true: "#5D4BC0" }}
        thumbColor={value ? ADMIN_COLORS.gold : "#B9C1D3"}
        accessibilityLabel={label}
      />
    </View>
  );
}

export function AdminPill({
  label,
  active = false,
  onPress,
}: {
  label: string;
  active?: boolean;
  onPress?: () => void;
}) {
  const Content = (
    <View style={[styles.pill, active && styles.pillActive]}>
      <Text style={[styles.pillText, active && styles.pillTextActive]}>{label}</Text>
    </View>
  );
  if (!onPress) return Content;
  return (
    <Pressable onPress={onPress} accessibilityRole="button">
      {Content}
    </Pressable>
  );
}

export function AdminNotice({
  message,
  kind = "info",
}: {
  message: string;
  kind?: "info" | "success" | "error";
}) {
  const color =
    kind === "success"
      ? ADMIN_COLORS.green
      : kind === "error"
        ? ADMIN_COLORS.red
        : ADMIN_COLORS.blue;
  return (
    <View style={[styles.notice, { borderColor: `${color}55`, backgroundColor: `${color}12` }]}>
      <Feather
        name={kind === "success" ? "check-circle" : kind === "error" ? "alert-circle" : "info"}
        size={16}
        color={color}
      />
      <Text style={[styles.noticeText, { color }]}>{message}</Text>
    </View>
  );
}

export function AdminLoading({ label = "Loading verified data…" }: { label?: string }) {
  return (
    <View style={styles.loading}>
      <ActivityIndicator color={ADMIN_COLORS.gold} />
      <Text style={styles.muted}>{label}</Text>
    </View>
  );
}

export function formatBytes(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "Not available";
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  return `${(value / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export function formatDate(value: string | null | undefined) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString();
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 20,
    borderWidth: 1,
    borderColor: ADMIN_COLORS.border,
    padding: 18,
    overflow: "hidden",
    shadowColor: "#090C19",
    shadowOpacity: 0.35,
    shadowOffset: { width: 0, height: 12 },
    shadowRadius: 22,
    elevation: 6,
  },
  cardHeading: { marginBottom: 14, gap: 4 },
  cardTitle: { color: ADMIN_COLORS.text, fontSize: 16, fontWeight: "700" },
  cardSubtitle: { color: ADMIN_COLORS.muted, fontSize: 12, lineHeight: 18 },
  buttonOuter: { borderRadius: 12, overflow: "hidden", alignSelf: "flex-start" },
  button: {
    minHeight: 42,
    paddingHorizontal: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 12,
  },
  buttonCompact: { minHeight: 34, paddingHorizontal: 11 },
  quietButton: { borderWidth: 1, borderColor: ADMIN_COLORS.border },
  buttonText: { color: ADMIN_COLORS.text, fontSize: 13, fontWeight: "700" },
  quietText: { color: ADMIN_COLORS.muted },
  disabled: { opacity: 0.5 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
  field: { gap: 7, marginBottom: 13, minWidth: 150, flexGrow: 1 },
  fieldLabel: { color: "#BDC5D7", fontSize: 12, fontWeight: "600" },
  input: {
    minHeight: 44,
    borderRadius: 11,
    borderWidth: 1,
    borderColor: ADMIN_COLORS.border,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: ADMIN_COLORS.text,
    backgroundColor: "rgba(6, 11, 24, 0.58)",
    fontSize: 14,
    outlineStyle: "none",
  } as never,
  multiline: { minHeight: 90, textAlignVertical: "top" },
  switchRow: {
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "rgba(157, 169, 203, 0.12)",
    gap: 14,
  },
  switchCopy: { flex: 1, gap: 3 },
  switchTitle: { color: ADMIN_COLORS.text, fontSize: 14, fontWeight: "600" },
  switchDescription: { color: ADMIN_COLORS.muted, fontSize: 12, lineHeight: 17 },
  pill: {
    borderWidth: 1,
    borderColor: ADMIN_COLORS.border,
    borderRadius: 999,
    paddingHorizontal: 11,
    paddingVertical: 7,
    backgroundColor: "rgba(12, 17, 31, 0.5)",
  },
  pillActive: { borderColor: "rgba(216, 181, 90, 0.65)", backgroundColor: "rgba(216,181,90,0.12)" },
  pillText: { color: ADMIN_COLORS.muted, fontSize: 11, fontWeight: "600" },
  pillTextActive: { color: ADMIN_COLORS.gold },
  notice: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    padding: 12,
    borderWidth: 1,
    borderRadius: 12,
  },
  noticeText: { flex: 1, fontSize: 12, lineHeight: 18 },
  loading: { minHeight: 100, alignItems: "center", justifyContent: "center", gap: 12 },
  muted: { color: ADMIN_COLORS.muted, fontSize: 12 },
});

