import React, { ReactNode } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useAppState } from '@/components/AppState';

export const profilePhoto = require('@/assets/images/ismail-profile.png');

export function Screen({
  children,
  scroll = true,
}: {
  children: ReactNode;
  scroll?: boolean;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const content = scroll ? (
    <ScrollView
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      {children}
    </ScrollView>
  ) : (
    <View style={styles.fixedContent}>{children}</View>
  );

  return (
    <SafeAreaView
      edges={['left', 'right']}
      style={[
        styles.safeArea,
        { backgroundColor: colors.background, paddingTop: topInset },
      ]}
    >
      {content}
    </SafeAreaView>
  );
}

export function ScreenHeader({
  eyebrow,
  title,
  action,
}: {
  eyebrow?: string;
  title: string;
  action?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.header}>
      <View style={styles.headerCopy}>
        {eyebrow ? (
          <Text style={[styles.eyebrow, { color: colors.gold }]}>{eyebrow}</Text>
        ) : null}
        <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
      </View>
      {action}
    </View>
  );
}

export function SectionHeading({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      {action && onAction ? (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={[styles.sectionAction, { color: colors.gold }]}>
            {action}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function Avatar({
  size = 46,
  online = false,
  framed = false,
}: {
  size?: number;
  online?: boolean;
  framed?: boolean;
}) {
  const colors = useColors();
  const { activeFrame, profileImage } = useAppState();
  const frameColor =
    colors.frameColors[activeFrame as keyof typeof colors.frameColors] ?? colors.gold;
  return (
    <View
      style={[
        styles.avatarFrame,
        {
          width: size + (framed ? 10 : 4),
          height: size + (framed ? 10 : 4),
          borderColor: framed ? frameColor : colors.border,
          borderWidth: framed ? 2 : 1,
          shadowColor: framed ? frameColor : 'transparent',
          shadowOpacity: framed ? 0.5 : 0,
          shadowRadius: framed ? 9 : 0,
          elevation: framed ? 4 : 0,
        },
      ]}
    >
      <Image
        source={profileImage ? { uri: profileImage } : profilePhoto}
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.surfaceRaised,
        }}
        contentFit="cover"
        accessibilityLabel="Profile portrait"
      />
      {online ? (
        <View
          style={[
            styles.onlineDot,
            { borderColor: colors.background, backgroundColor: colors.online },
          ]}
        />
      ) : null}
    </View>
  );
}

export function PreviewNotice({
  text,
  icon = 'info',
}: {
  text: string;
  icon?: keyof typeof Feather.glyphMap;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.notice,
        { borderColor: colors.border, backgroundColor: colors.surface },
      ]}
    >
      <Feather name={icon} size={15} color={colors.gold} />
      <Text style={[styles.noticeText, { color: colors.mutedForeground }]}>
        {text}
      </Text>
    </View>
  );
}

export function IconButton({
  icon,
  onPress,
  label,
}: {
  icon: keyof typeof Feather.glyphMap;
  onPress: () => void;
  label: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => [
        styles.iconButton,
        { borderColor: colors.border, backgroundColor: colors.surface },
        pressed && styles.pressed,
      ]}
    >
      <Feather name={icon} size={18} color={colors.foreground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  scrollContent: { paddingHorizontal: 20, paddingBottom: 112, gap: 25 },
  fixedContent: { flex: 1, paddingHorizontal: 20 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 14,
    paddingTop: 11,
  },
  headerCopy: { flex: 1, gap: 5 },
  eyebrow: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2.1,
    textTransform: 'uppercase',
  },
  title: { fontSize: 27, lineHeight: 33, fontWeight: '700', letterSpacing: -0.7 },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 13,
  },
  sectionTitle: { fontSize: 17, fontWeight: '700', letterSpacing: -0.2 },
  sectionAction: { fontSize: 12, fontWeight: '600' },
  avatarFrame: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 100,
    overflow: 'visible',
  },
  onlineDot: {
    position: 'absolute',
    width: 13,
    height: 13,
    right: -1,
    bottom: 1,
    borderWidth: 2,
    borderRadius: 7,
  },
  notice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
    paddingHorizontal: 12,
    paddingVertical: 11,
    borderWidth: 1,
    borderRadius: 13,
  },
  noticeText: { flex: 1, fontSize: 11, lineHeight: 16 },
  iconButton: {
    width: 42,
    height: 42,
    borderWidth: 1,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: { opacity: 0.75, transform: [{ scale: 0.97 }] },
});
