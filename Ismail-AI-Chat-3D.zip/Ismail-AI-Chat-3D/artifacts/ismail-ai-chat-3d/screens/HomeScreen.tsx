import React, { useMemo, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Avatar, IconButton, PreviewNotice, Screen, SectionHeading } from '@/components/AppChrome';
import { useAppState } from '@/components/AppState';
import { useColors } from '@/hooks/useColors';

const people = [
  { name: 'Areeba Khan', handle: '@areeba', online: true, note: 'Designing dreams' },
  { name: 'Zayan Malik', handle: '@zayan.m', online: true, note: 'Listening now' },
  { name: 'Noor Fatima', handle: '@noor.f', online: false, note: 'In your circle' },
];

const roomImage = require('@/assets/images/voice-room.png');

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { activeFrame } = useAppState();
  const [query, setQuery] = useState('');
  const filteredPeople = useMemo(
    () =>
      people.filter((person) =>
        `${person.name} ${person.handle}`.toLowerCase().includes(query.toLowerCase()),
      ),
    [query],
  );

  return (
    <Screen>
      <View style={styles.topBar}>
        <View style={styles.brand}>
          <Image source={require('@/assets/images/icon.png')} style={styles.brandIcon} />
          <View>
            <Text style={[styles.brandName, { color: colors.foreground }]}>ISMAIL</Text>
            <Text style={[styles.brandLabel, { color: colors.gold }]}>SOCIAL CLUB</Text>
          </View>
        </View>
        <View style={styles.topActions}>
          <IconButton
            icon="bell"
            label="Notifications"
            onPress={() => Alert.alert('Notifications', 'Push notifications are not connected yet.')}
          />
          <Pressable onPress={() => router.push('/(tabs)/profile')} accessibilityRole="button">
            <Avatar size={37} framed />
          </Pressable>
        </View>
      </View>

      <LinearGradient
        colors={[colors.heroTop, colors.heroBottom]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.hero}
      >
        <View style={styles.heroOrb} />
        <View style={styles.heroTopLine}>
          <View style={[styles.previewBadge, { backgroundColor: colors.glass }]}>
            <View style={[styles.liveDot, { backgroundColor: colors.online }]} />
            <Text style={[styles.previewBadgeText, { color: colors.foreground }]}>
              YOUR SPACE
            </Text>
          </View>
          <Pressable
            onPress={() => router.push('/assistant')}
            style={({ pressed }) => [styles.sparkleButton, pressed && styles.pressed]}
            accessibilityRole="button"
            accessibilityLabel="Open AI assistant"
          >
            <Feather name="command" size={17} color={colors.goldBright} />
          </Pressable>
        </View>
        <Text style={[styles.heroTitle, { color: colors.foreground }]}>
          A little closer.{'\n'}
          <Text style={{ color: colors.goldBright }}>A lot more you.</Text>
        </Text>
        <Text style={[styles.heroSubtitle, { color: colors.heroText }]}>
          Your people, your rooms, your moment.
        </Text>
        <View style={styles.heroBottom}>
          <View style={styles.miniFaces}>
            {people.slice(0, 3).map((person, index) => (
              <View
                key={person.handle}
                style={[
                  styles.miniFace,
                  {
                    marginLeft: index === 0 ? 0 : -10,
                    borderColor: colors.heroBottom,
                  },
                ]}
              >
                <Image source={require('@/assets/images/ismail-profile.png')} style={styles.miniFaceImg} />
              </View>
            ))}
            <Text style={[styles.onlineLabel, { color: colors.heroText }]}>12 friends online</Text>
          </View>
          <Pressable
            onPress={() => router.push('/(tabs)/rooms')}
            style={({ pressed }) => [
              styles.heroAction,
              { backgroundColor: colors.gold },
              pressed && styles.pressed,
            ]}
            accessibilityRole="button"
          >
            <Text style={[styles.heroActionText, { color: colors.background }]}>Explore</Text>
            <Feather name="arrow-up-right" size={15} color={colors.background} />
          </Pressable>
        </View>
      </LinearGradient>

      <View style={styles.quickStats}>
        <QuickStat icon="message-circle" value="08" label="Messages" onPress={() => router.push('/(tabs)/messages')} />
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <QuickStat icon="headphones" value="04" label="Live rooms" onPress={() => router.push('/(tabs)/rooms')} />
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <QuickStat icon="gift" value="12" label="New gifts" onPress={() => router.push('/(tabs)/gifts')} />
      </View>
      <PreviewNotice text="Preview mode — people, counts, and room activity are sample content, not live account data." />

      <View>
        <SectionHeading
          title="Find your people"
          action="See all"
          onAction={() => router.push('/(tabs)/messages')}
        />
        <View style={[styles.search, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search names or usernames"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.searchInput, { color: colors.foreground }]}
            accessibilityLabel="Search users"
          />
          <Feather name="sliders" size={15} color={colors.mutedForeground} />
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.peopleRow}>
          {filteredPeople.length ? (
            filteredPeople.map((person, index) => (
              <PersonChip key={person.handle} person={person} index={index} />
            ))
          ) : (
            <Text style={[styles.noResults, { color: colors.mutedForeground }]}>
              No people match “{query}”.
            </Text>
          )}
        </ScrollView>
      </View>

      <View>
        <SectionHeading
          title="In the room tonight"
          action="All rooms"
          onAction={() => router.push('/(tabs)/rooms')}
        />
        <Pressable
          onPress={() => router.push('/(tabs)/rooms')}
          style={({ pressed }) => [styles.roomCard, pressed && styles.pressed]}
          accessibilityRole="button"
        >
          <Image source={roomImage} style={StyleSheet.absoluteFill} contentFit="cover" />
          <LinearGradient
            colors={['transparent', 'rgba(5, 8, 19, 0.94)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={[styles.roomLive, { backgroundColor: colors.danger }]}>
            <View style={styles.roomLiveDot} />
            <Text style={styles.roomLiveText}>LIVE NOW</Text>
          </View>
          <View style={styles.roomDetails}>
            <Text style={[styles.roomTitle, { color: colors.foreground }]}>After Hours</Text>
            <Text style={[styles.roomSub, { color: colors.heroText }]}>with Areeba · 8 seats open</Text>
            <View style={styles.roomFooter}>
              <View style={styles.roomAvatars}>
                {[0, 1, 2].map((n) => (
                  <Image
                    key={n}
                    source={require('@/assets/images/ismail-profile.png')}
                    style={[
                      styles.roomAvatar,
                      { marginLeft: n === 0 ? 0 : -8, borderColor: colors.background },
                    ]}
                  />
                ))}
                <Text style={[styles.roomCount, { color: colors.heroText }]}>+18</Text>
              </View>
              <Feather name="arrow-up-right" size={18} color={colors.goldBright} />
            </View>
          </View>
        </Pressable>
        <PreviewNotice text="Preview mode — room presence and live audio are not connected yet." icon="radio" />
      </View>

      <View style={[styles.vipCard, { backgroundColor: colors.surface, borderColor: colors.goldBorder }]}>
        <View style={[styles.vipIcon, { backgroundColor: colors.goldWash }]}>
          <Feather name="award" size={19} color={colors.gold} />
        </View>
        <View style={styles.vipCopy}>
          <Text style={[styles.vipTitle, { color: colors.foreground }]}>Make it unmistakably yours</Text>
          <Text style={[styles.vipSubtitle, { color: colors.mutedForeground }]}>
            Preview 7 luminous profile frames
          </Text>
        </View>
        <Pressable onPress={() => router.push('/(tabs)/profile')} accessibilityRole="button">
          <Feather name="arrow-right" size={18} color={colors.gold} />
        </Pressable>
      </View>
      <Text style={[styles.frameFootnote, { color: colors.mutedForeground }]}>
        Active profile frame · {activeFrame}
      </Text>
    </Screen>
  );
}

function QuickStat({
  icon,
  value,
  label,
  onPress,
}: {
  icon: keyof typeof Feather.glyphMap;
  value: string;
  label: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable onPress={onPress} style={styles.stat} accessibilityRole="button">
      <Feather name={icon} size={15} color={colors.gold} />
      <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </Pressable>
  );
}

function PersonChip({
  person,
  index,
}: {
  person: (typeof people)[number];
  index: number;
}) {
  const colors = useColors();
  return (
    <View style={[styles.personChip, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Avatar size={34} online={person.online} framed={index === 0} />
      <View style={styles.personCopy}>
        <Text style={[styles.personName, { color: colors.foreground }]} numberOfLines={1}>
          {person.name}
        </Text>
        <Text style={[styles.personNote, { color: colors.mutedForeground }]} numberOfLines={1}>
          {person.note}
        </Text>
      </View>
      <Feather name={person.online ? 'radio' : 'user'} size={13} color={colors.mutedForeground} />
    </View>
  );
}

const styles = StyleSheet.create({
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  brandIcon: { width: 37, height: 37, borderRadius: 12 },
  brandName: { fontSize: 13, fontWeight: '800', letterSpacing: 2.2 },
  brandLabel: { fontSize: 8, fontWeight: '700', letterSpacing: 1.6, marginTop: 2 },
  topActions: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  hero: { minHeight: 245, padding: 20, borderRadius: 24, overflow: 'hidden', justifyContent: 'space-between' },
  heroOrb: {
    position: 'absolute',
    width: 220,
    height: 220,
    borderRadius: 120,
    borderWidth: 1,
    borderColor: 'rgba(230, 189, 104, .18)',
    right: -74,
    top: -90,
    shadowColor: '#D7AD5E',
    shadowOpacity: 0.2,
    shadowRadius: 28,
  },
  heroTopLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  previewBadge: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 50 },
  liveDot: { width: 6, height: 6, borderRadius: 4 },
  previewBadgeText: { fontSize: 9, letterSpacing: 1.4, fontWeight: '700' },
  sparkleButton: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  heroTitle: { fontSize: 28, fontWeight: '700', lineHeight: 34, letterSpacing: -0.8, marginTop: 13 },
  heroSubtitle: { fontSize: 12, marginTop: -7 },
  heroBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 20 },
  miniFaces: { flexDirection: 'row', alignItems: 'center' },
  miniFace: { width: 26, height: 26, borderRadius: 14, borderWidth: 2, overflow: 'hidden' },
  miniFaceImg: { width: 24, height: 24, borderRadius: 12 },
  onlineLabel: { fontSize: 10, marginLeft: 9 },
  heroAction: { borderRadius: 13, flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 13, paddingVertical: 10 },
  heroActionText: { fontSize: 11, fontWeight: '700' },
  pressed: { opacity: 0.77, transform: [{ scale: 0.985 }] },
  quickStats: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingVertical: 3 },
  stat: { flex: 1, alignItems: 'center', gap: 4 },
  statValue: { fontSize: 14, fontWeight: '700' },
  statLabel: { fontSize: 9 },
  statDivider: { width: 1, height: 34 },
  search: { height: 47, borderWidth: 1, borderRadius: 15, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 13 },
  searchInput: { flex: 1, paddingVertical: 0, fontSize: 12 },
  peopleRow: { gap: 9, paddingTop: 12, paddingBottom: 2 },
  personChip: { minWidth: 178, maxWidth: 210, flexDirection: 'row', alignItems: 'center', gap: 9, borderWidth: 1, borderRadius: 16, padding: 10 },
  personCopy: { flex: 1 },
  personName: { fontSize: 10, fontWeight: '700' },
  personNote: { fontSize: 9, marginTop: 4 },
  noResults: { paddingVertical: 12, fontSize: 12 },
  roomCard: { height: 192, borderRadius: 20, overflow: 'hidden', justifyContent: 'space-between', padding: 14, marginBottom: 12 },
  roomLive: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 30 },
  roomLiveDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#FFFFFF' },
  roomLiveText: { color: '#FFFFFF', fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  roomDetails: { gap: 7 },
  roomTitle: { fontSize: 21, fontWeight: '700', letterSpacing: -0.3 },
  roomSub: { fontSize: 10 },
  roomFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  roomAvatars: { flexDirection: 'row', alignItems: 'center' },
  roomAvatar: { width: 22, height: 22, borderRadius: 12, borderWidth: 2 },
  roomCount: { fontSize: 9, marginLeft: 7 },
  vipCard: { borderWidth: 1, borderRadius: 18, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 12 },
  vipIcon: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  vipCopy: { flex: 1, gap: 4 },
  vipTitle: { fontSize: 11, fontWeight: '700' },
  vipSubtitle: { fontSize: 9 },
  frameFootnote: { marginTop: -17, textAlign: 'center', fontSize: 9, textTransform: 'capitalize' },
});
