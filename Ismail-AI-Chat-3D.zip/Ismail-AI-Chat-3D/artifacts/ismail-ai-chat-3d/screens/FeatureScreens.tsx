import React, { useMemo, useState } from 'react';
import {
  Alert,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import { useGetPublicCatalog } from '@workspace/api-client-react';
import { Avatar, IconButton, PreviewNotice, Screen, ScreenHeader, SectionHeading } from '@/components/AppChrome';
import { FrameId, useAppState } from '@/components/AppState';
import { resolveApiUrl } from '@/lib/api-url';
import { useColors } from '@/hooks/useColors';

const avatarImage = require('@/assets/images/ismail-profile.png');
const roomImage = require('@/assets/images/voice-room.png');

const conversations = [
  { name: 'Areeba Khan', handle: '@areeba', message: 'That room was such a vibe', time: '2m', unread: 2, online: true },
  { name: 'Zayan Malik', handle: '@zayan.m', message: 'Sent you a voice note', time: '18m', unread: 0, online: true },
  { name: 'Noor Fatima', handle: '@noor.f', message: 'Thank you for the rose!', time: '1h', unread: 0, online: false },
  { name: 'Sara Ahmed', handle: '@sara.a', message: 'Are you joining tonight?', time: '3h', unread: 1, online: false },
];

const rooms = [
  { title: 'After Hours', host: 'Areeba Khan', count: '21 listening', seats: '8 seats', tone: 'gold' as const },
  { title: 'The Open Mic', host: 'Zayan Malik', count: '14 listening', seats: '12 seats', tone: 'blue' as const },
  { title: 'Soft Launch', host: 'Noor Fatima', count: '08 listening', seats: '8 seats', tone: 'purple' as const },
];

const frameOptions: { id: FrameId; name: string; subtitle: string; icon: keyof typeof Feather.glyphMap }[] = [
  { id: 'gold', name: 'Gold', subtitle: 'Signature', icon: 'award' },
  { id: 'diamond', name: 'Diamond', subtitle: 'Brilliant', icon: 'hexagon' },
  { id: 'crystal', name: 'Crystal', subtitle: 'Prismatic', icon: 'triangle' },
  { id: 'rainbow', name: 'Spectrum', subtitle: 'Full color', icon: 'sun' },
  { id: 'fire', name: 'Ember', subtitle: 'Warm glow', icon: 'zap' },
  { id: 'ice', name: 'Frost', subtitle: 'Cool light', icon: 'cloud-snow' },
  { id: 'galaxy', name: 'Galaxy', subtitle: 'Starlit', icon: 'moon' },
];

export function MessagesScreen() {
  const colors = useColors();
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'unread' | 'requests'>('all');
  const filtered = useMemo(
    () =>
      conversations
        .filter((item) => `${item.name} ${item.handle}`.toLowerCase().includes(query.toLowerCase()))
        .filter((item) => activeFilter !== 'unread' || item.unread > 0)
        .filter((item) => activeFilter !== 'requests'),
    [query, activeFilter],
  );
  return (
    <Screen>
      <ScreenHeader eyebrow="YOUR INBOX" title="Messages" action={<IconButton icon="edit-3" label="Compose message" onPress={() => Alert.alert('Preview only', 'Private messaging will be enabled when account and messaging services are connected.')} />} />
      <PreviewNotice text="Sample conversations only. Live chat, delivery status, and sync are not connected yet." icon="message-circle" />
      <SearchField value={query} onChangeText={setQuery} placeholder="Search conversations" />
      <View style={styles.filterRow}>
        <FilterPill label="All" active={activeFilter === 'all'} onPress={() => setActiveFilter('all')} />
        <FilterPill label="Unread" active={activeFilter === 'unread'} onPress={() => setActiveFilter('unread')} />
        <FilterPill label="Requests" active={activeFilter === 'requests'} onPress={() => setActiveFilter('requests')} />
      </View>
      <View style={styles.conversationList}>
        {activeFilter === 'requests' ? (
          <EmptyState title="No message requests" detail="Requests will appear after accounts are connected." />
        ) : filtered.length ? filtered.map((item, index) => (
          <Pressable
            key={item.handle}
            onPress={() => Alert.alert('Conversation preview', `${item.name} · ${item.message}\n\nLive message history is not connected yet.`)}
            style={({ pressed }) => [styles.conversation, { borderBottomColor: colors.border }, pressed && styles.pressed]}
            accessibilityRole="button"
          >
            <Avatar size={49} online={item.online} framed={index === 0} />
            <View style={styles.conversationCopy}>
              <View style={styles.nameLine}>
                <Text style={[styles.personName, { color: colors.foreground }]}>{item.name}</Text>
                <Text style={[styles.time, { color: colors.mutedForeground }]}>{item.time}</Text>
              </View>
              <View style={styles.messageLine}>
                <Text style={[styles.lastMessage, { color: item.unread ? colors.foreground : colors.mutedForeground }]} numberOfLines={1}>
                  {item.message}
                </Text>
                {item.unread > 0 ? <View style={[styles.unread, { backgroundColor: colors.gold }]}><Text style={[styles.unreadText, { color: colors.background }]}>{item.unread}</Text></View> : null}
              </View>
            </View>
          </Pressable>
        )) : <EmptyState title="No conversations found" detail="Try another name or username." />}
      </View>
    </Screen>
  );
}

export function RoomsScreen() {
  const colors = useColors();
  return (
    <Screen>
      <ScreenHeader eyebrow="LIVE TOGETHER" title="Voice rooms" action={<IconButton icon="search" label="Search rooms" onPress={() => Alert.alert('Room search', 'Room discovery is shown as a preview. Live room search is not connected yet.')} />} />
      <LinearGradient colors={[colors.heroTop, colors.heroBottom]} style={styles.roomFeature}>
        <Image source={roomImage} style={StyleSheet.absoluteFill} contentFit="cover" />
        <LinearGradient colors={['rgba(8, 11, 24, .15)', 'rgba(8, 11, 24, .95)']} style={StyleSheet.absoluteFill} />
        <View style={styles.roomFeatureTop}>
          <View style={[styles.liveBadge, { backgroundColor: colors.danger }]}><View style={styles.whiteDot} /><Text style={styles.liveText}>LIVE NOW</Text></View>
          <Feather name="radio" size={18} color={colors.goldBright} />
        </View>
        <View>
          <Text style={[styles.roomTitle, { color: colors.foreground }]}>Voices after dark</Text>
          <Text style={[styles.roomSubtitle, { color: colors.heroText }]}>Find your people. Stay for the conversation.</Text>
        </View>
      </LinearGradient>
      <PreviewNotice text="Room cards are interactive previews. Live voice requires a configured audio provider." icon="mic" />
      <SectionHeading title="Rooms to explore" action="Filters" onAction={() => Alert.alert('Room filters', '8-seat and 12-seat room layouts are part of the preview.')} />
      <View style={styles.roomList}>
        {rooms.map((room, index) => (
          <RoomCard key={room.title} room={room} index={index} />
        ))}
      </View>
      <View style={[styles.seatInfo, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Feather name="users" size={16} color={colors.gold} />
        <Text style={[styles.seatInfoText, { color: colors.mutedForeground }]}>Layouts preview both 8-seat and 12-seat rooms.</Text>
      </View>
    </Screen>
  );
}

export function GiftsScreen() {
  const colors = useColors();
  const catalog = useGetPublicCatalog({ query: { retry: false, staleTime: 60_000 } });
  const [selected, setSelected] = useState<string | null>(null);
  const gifts = catalog.data?.gifts ?? [];
  const catalogSettings = catalog.data?.settings.catalogAppearance;
  const catalogTitle = catalogSettings?.title || 'Made to be sent';
  const isListLayout = catalogSettings?.layout === 'list';
  return (
    <Screen>
      <ScreenHeader eyebrow="LITTLE MOMENTS, BIG FEELING" title="Gift lounge" action={<IconButton icon="archive" label="Gift inventory" onPress={() => Alert.alert('Gift inventory', 'Your gift inventory will appear here after accounts and the gift service are connected.')} />} />
      <LinearGradient colors={[colors.heroTop, colors.surface]} style={styles.giftBalance}>
        <View style={styles.balanceIcon}><Feather name="hexagon" size={19} color={colors.goldBright} /></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.balanceLabel, { color: colors.heroText }]}>YOUR GIFT BALANCE</Text>
          <Text style={[styles.balanceAmount, { color: colors.foreground }]}>— <Text style={[styles.balanceUnit, { color: colors.mutedForeground }]}>credits</Text></Text>
        </View>
        <Text style={[styles.notConnected, { color: colors.gold }]}>Not connected</Text>
      </LinearGradient>
      <PreviewNotice
        text={
          catalog.isError
            ? 'The published catalog could not be loaded. No sample gifts are shown.'
            : 'Browse published gifts. Sending gifts and managing balances are not connected.'
        }
        icon="gift"
      />
      <SectionHeading title={catalogTitle} action="See all" onAction={() => setSelected(null)} />
      {catalog.isLoading ? (
        <EmptyState title="Loading gift catalog" detail="Published gifts will appear here." />
      ) : gifts.length === 0 ? (
        <EmptyState title="No published gifts" detail="Published catalog items will appear here when available." />
      ) : null}
      <View style={[styles.giftGrid, isListLayout && { flexDirection: 'column' }]}>
        {gifts.map((gift, index) => (
          <Pressable
            key={gift.id}
            onPress={() => {
              setSelected(gift.id);
              Alert.alert(
                'Gift preview',
                `${gift.name}${catalogSettings?.showPrices === false ? '' : ` · ${gift.price} credits`}\n\n${gift.description || 'Published catalog gift.'}\n\nNo gift was sent and no balance was charged.`,
              );
            }}
            style={({ pressed }) => [
              styles.giftCard,
              {
                backgroundColor: colors.surface,
                borderColor: selected === gift.id ? colors.gold : colors.border,
                ...(isListLayout ? { width: '100%', flexDirection: 'row', alignItems: 'center', gap: 12 } : {}),
              },
              pressed && styles.pressed,
            ]}
            accessibilityRole="button"
          >
            <LinearGradient colors={[colors.goldWash, colors.surface]} style={[styles.giftArt, isListLayout && { width: 82, height: 82, flexShrink: 0 }]}>
              {gift.thumbnailUrl ? (
                <Image
                  source={{ uri: resolveApiUrl(gift.thumbnailUrl) }}
                  style={{ width: '100%', height: '100%' }}
                  contentFit="contain"
                  accessibilityLabel={`${gift.name} gift thumbnail`}
                />
              ) : (
                <Feather name={index % 2 ? 'star' : 'gift'} size={25} color={index === 2 ? colors.crystal : colors.goldBright} />
              )}
              <View style={[styles.giftSpark, { backgroundColor: colors.goldBright }]} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.giftName, { color: colors.foreground }]}>{gift.name}</Text>
              <Text style={[styles.giftDetail, { color: colors.mutedForeground }]} numberOfLines={2}>{gift.description}</Text>
              {catalogSettings?.showPrices !== false ? (
                <View style={styles.giftPriceRow}>
                  <Feather name="hexagon" size={11} color={colors.gold} />
                  <Text style={[styles.giftPrice, { color: colors.gold }]}>{gift.price}</Text>
                  <Feather name="arrow-up-right" size={13} color={colors.mutedForeground} style={{ marginLeft: 'auto' }} />
                </View>
              ) : null}
            </View>
          </Pressable>
        ))}
      </View>
      <View style={[styles.vipBanner, { borderColor: colors.goldBorder, backgroundColor: colors.goldWash }]}>
        <Feather name="award" size={17} color={colors.gold} />
        <View style={{ flex: 1 }}>
          <Text style={[styles.vipBannerTitle, { color: colors.foreground }]}>A little extra sparkle</Text>
          <Text style={[styles.giftDetail, { color: colors.mutedForeground }]}>
            {catalog.data?.vipLevels.length
              ? `${catalog.data.vipLevels.length} VIP levels in the catalog · purchases are not connected`
              : 'Membership and benefits are not connected yet.'}
          </Text>
        </View>
        <Feather name="chevron-right" size={16} color={colors.gold} />
      </View>
    </Screen>
  );
}

export function ProfileScreen() {
  const colors = useColors();
  const { activeFrame, setActiveFrame, profileImage, setProfileImage, isLoaded } = useAppState();
  const [isPicking, setIsPicking] = useState(false);
  const activeColor = colors.frameColors[activeFrame];

  const pickPhoto = async () => {
    setIsPicking(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.86,
      });
      if (!result.canceled && result.assets[0]?.uri) {
        setProfileImage(result.assets[0].uri);
      }
    } catch {
      Alert.alert('Photo unavailable', 'Could not open your photo library. Please try again.');
    } finally {
      setIsPicking(false);
    }
  };

  return (
    <Screen>
      <ScreenHeader eyebrow="YOUR PROFILE" title="Your signature" action={<IconButton icon="settings" label="Profile settings" onPress={() => Alert.alert('Profile settings', 'Account settings will be available once sign-in is connected.')} />} />
      <View style={styles.profileHero}>
        <View style={[styles.profileGlow, { borderColor: activeColor, shadowColor: activeColor }]}>
          <Image source={profileImage ? { uri: profileImage } : avatarImage} style={styles.profilePhoto} contentFit="cover" />
          <View style={[styles.frameSpark, { backgroundColor: colors.goldBright }]} />
        </View>
        <Text style={[styles.profileName, { color: colors.foreground }]}>Ismail</Text>
        <Text style={[styles.profileHandle, { color: colors.mutedForeground }]}>@ismail · profile preview</Text>
        <Pressable
          onPress={pickPhoto}
          disabled={isPicking}
          style={({ pressed }) => [styles.changePhoto, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}
          accessibilityRole="button"
        >
          <Feather name="image" size={14} color={colors.gold} />
          <Text style={[styles.changePhotoText, { color: colors.foreground }]}>{isPicking ? 'Opening photos…' : 'Change photo'}</Text>
        </Pressable>
      </View>
      <PreviewNotice text="Photo and frame preferences save on this device only. Account sync is not connected." icon="smartphone" />
      <View>
        <SectionHeading title="Choose your frame" />
        <Text style={[styles.frameIntro, { color: colors.mutedForeground }]}>A little light that follows you through the app.</Text>
        <View style={styles.frameGrid}>
          {frameOptions.map((frame) => {
            const selected = activeFrame === frame.id;
            const tone = colors.frameColors[frame.id];
            return (
              <Pressable
                key={frame.id}
                onPress={() => setActiveFrame(frame.id)}
                style={({ pressed }) => [
                  styles.frameOption,
                  { backgroundColor: colors.surface, borderColor: selected ? tone : colors.border },
                  selected && { shadowColor: tone, shadowOpacity: 0.18, shadowRadius: 10, elevation: 2 },
                  pressed && styles.pressed,
                ]}
                accessibilityRole="button"
                accessibilityState={{ selected }}
                testID={`frame-${frame.id}`}
              >
                <View style={[styles.frameIcon, { backgroundColor: `${tone}20`, borderColor: tone }]}>
                  <Feather name={frame.icon} size={17} color={tone} />
                </View>
                <Text style={[styles.frameName, { color: colors.foreground }]}>{frame.name}</Text>
                <Text style={[styles.frameSubtitle, { color: colors.mutedForeground }]}>{frame.subtitle}</Text>
                {selected ? <Feather name="check" size={13} color={tone} style={styles.frameCheck} /> : null}
              </Pressable>
            );
          })}
        </View>
      </View>
      <View style={[styles.vipProfileCard, { backgroundColor: colors.surface, borderColor: colors.goldBorder }]}>
        <View style={[styles.vipBadge, { backgroundColor: colors.goldWash }]}><Feather name="award" size={16} color={colors.gold} /></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.vipBannerTitle, { color: colors.foreground }]}>VIP membership</Text>
          <Text style={[styles.giftDetail, { color: colors.mutedForeground }]}>Membership options are not connected yet.</Text>
        </View>
        <Text style={[styles.notConnected, { color: colors.gold }]}>{isLoaded ? 'Preview' : 'Loading'}</Text>
      </View>
    </Screen>
  );
}

export function AssistantScreen() {
  const colors = useColors();
  const router = useRouter();
  const [draft, setDraft] = useState('');
  return (
    <Screen>
      <ScreenHeader eyebrow="A THOUGHTFUL SIDEKICK" title="Ismail AI" action={<IconButton icon="x" label="Close assistant" onPress={() => router.back()} />} />
      <LinearGradient colors={[colors.heroTop, colors.heroBottom]} style={styles.aiHero}>
        <View style={[styles.aiOrb, { borderColor: colors.goldBorder, backgroundColor: colors.goldWash }]}>
          <Feather name="command" size={23} color={colors.goldBright} />
          <View style={[styles.aiOrbDot, { backgroundColor: colors.crystal }]} />
        </View>
        <Text style={[styles.aiTitle, { color: colors.foreground }]}>Here when words don’t come.</Text>
        <Text style={[styles.aiSubtitle, { color: colors.heroText }]}>Urdu, Roman Urdu, English — conversation is the point.</Text>
        <View style={[styles.connectionTag, { borderColor: colors.goldBorder }]}>
          <View style={[styles.connectionDot, { backgroundColor: colors.warning }]} />
          <Text style={[styles.connectionText, { color: colors.heroText }]}>AI service not connected</Text>
        </View>
      </LinearGradient>
      <PreviewNotice text="This screen is a UI preview. No AI response is generated until the secure backend connection is added." icon="lock" />
      <SectionHeading title="Things you can ask" />
      <View style={styles.promptList}>
        {['Help me write a warm reply', 'Explain something simply', 'Give me a fresh idea'].map((prompt) => (
          <Pressable
            key={prompt}
            onPress={() => setDraft(prompt)}
            style={({ pressed }) => [styles.promptChip, { borderColor: colors.border, backgroundColor: colors.surface }, pressed && styles.pressed]}
          >
            <Text style={[styles.promptText, { color: colors.foreground }]}>{prompt}</Text>
            <Feather name="arrow-up-right" size={13} color={colors.gold} />
          </Pressable>
        ))}
      </View>
      <View style={[styles.aiInputWrap, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <TextInput
          value={draft}
          onChangeText={setDraft}
          placeholder="AI replies are not enabled yet"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.aiInput, { color: colors.foreground }]}
          editable={false}
          accessibilityLabel="AI message input, unavailable until service connection"
        />
        <Feather name="lock" size={16} color={colors.mutedForeground} />
      </View>
    </Screen>
  );
}

function RoomCard({ room, index }: { room: (typeof rooms)[number]; index: number }) {
  const colors = useColors();
  const accent = room.tone === 'gold' ? colors.gold : room.tone === 'blue' ? colors.crystal : colors.amethyst;
  return (
    <Pressable
      onPress={() => Alert.alert('Room preview', `${room.title}\nHosted by ${room.host} · ${room.seats}\n\nLive audio and microphone controls require an audio service.`)}
      style={({ pressed }) => [styles.roomRow, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}
      accessibilityRole="button"
    >
      <View style={[styles.roomThumb, { backgroundColor: index === 0 ? colors.goldWash : colors.surfaceRaised }]}>
        <Image source={roomImage} style={StyleSheet.absoluteFill} contentFit="cover" />
        <View style={[styles.roomThumbTint, { backgroundColor: `${accent}45` }]} />
        <Feather name="radio" size={17} color={colors.foreground} />
      </View>
      <View style={styles.roomRowCopy}>
        <View style={styles.nameLine}>
          <Text style={[styles.personName, { color: colors.foreground }]}>{room.title}</Text>
          {index === 0 ? <Text style={[styles.liveMini, { color: colors.online }]}>LIVE</Text> : null}
        </View>
        <Text style={[styles.roomSubtitle, { color: colors.mutedForeground }]}>with {room.host} · {room.count}</Text>
        <Text style={[styles.roomSubtitle, { color: colors.mutedForeground }]}>{room.seats} · preview</Text>
      </View>
      <Feather name="arrow-up-right" size={16} color={colors.gold} />
    </Pressable>
  );
}

function SearchField({
  value,
  onChangeText,
  placeholder,
}: {
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
}) {
  const colors = useColors();
  return (
    <View style={[styles.search, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Feather name="search" size={16} color={colors.mutedForeground} />
      <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={colors.mutedForeground} style={[styles.searchInput, { color: colors.foreground }]} />
    </View>
  );
}

function FilterPill({ label, active = false, onPress }: { label: string; active?: boolean; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable onPress={onPress} style={[styles.filterPill, { backgroundColor: active ? colors.goldWash : colors.surface, borderColor: active ? colors.goldBorder : colors.border }]}>
      <Text style={[styles.filterText, { color: active ? colors.gold : colors.mutedForeground }]}>{label}</Text>
    </Pressable>
  );
}

function EmptyState({ title, detail }: { title: string; detail: string }) {
  const colors = useColors();
  return (
    <View style={styles.emptyState}>
      <Feather name="search" size={21} color={colors.mutedForeground} />
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDetail, { color: colors.mutedForeground }]}>{detail}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  pressed: { opacity: 0.76, transform: [{ scale: 0.985 }] },
  filterRow: { flexDirection: 'row', gap: 8 },
  filterPill: { paddingHorizontal: 15, paddingVertical: 9, borderRadius: 30, borderWidth: 1 },
  filterText: { fontSize: 11, fontWeight: '600' },
  conversationList: { marginTop: -6 },
  conversation: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingVertical: 14, borderBottomWidth: 1 },
  conversationCopy: { flex: 1, gap: 7 },
  nameLine: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  personName: { fontSize: 13, fontWeight: '700' },
  time: { marginLeft: 'auto', fontSize: 10 },
  messageLine: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  lastMessage: { flex: 1, fontSize: 11 },
  unread: { minWidth: 18, height: 18, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  unreadText: { fontSize: 9, fontWeight: '800' },
  search: { height: 47, borderWidth: 1, borderRadius: 15, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 13 },
  searchInput: { flex: 1, paddingVertical: 0, fontSize: 12 },
  emptyState: { alignItems: 'center', gap: 8, paddingTop: 38 },
  emptyTitle: { fontSize: 14, fontWeight: '700' },
  emptyDetail: { fontSize: 11 },
  roomFeature: { minHeight: 204, justifyContent: 'space-between', borderRadius: 22, padding: 17, overflow: 'hidden' },
  roomFeatureTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 30 },
  whiteDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#FFFFFF' },
  liveText: { color: '#FFFFFF', fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  roomTitle: { fontSize: 21, fontWeight: '700', marginBottom: 5 },
  roomSubtitle: { fontSize: 10, lineHeight: 15 },
  roomList: { gap: 9, marginTop: -12 },
  roomRow: { borderRadius: 17, borderWidth: 1, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 11 },
  roomThumb: { width: 48, height: 48, borderRadius: 14, overflow: 'hidden', justifyContent: 'center', alignItems: 'center' },
  roomThumbTint: { ...StyleSheet.absoluteFill },
  roomRowCopy: { flex: 1, gap: 3 },
  liveMini: { fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  seatInfo: { flexDirection: 'row', alignItems: 'center', gap: 9, borderWidth: 1, borderRadius: 14, padding: 12 },
  seatInfoText: { fontSize: 10, flex: 1 },
  giftBalance: { minHeight: 103, borderRadius: 20, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 13, borderWidth: 1, borderColor: 'rgba(218, 184, 110, .20)' },
  balanceIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: 'rgba(218, 184, 110, .12)', alignItems: 'center', justifyContent: 'center' },
  balanceLabel: { fontSize: 9, letterSpacing: 1.5, fontWeight: '700', marginBottom: 7 },
  balanceAmount: { fontSize: 21, fontWeight: '700' },
  balanceUnit: { fontSize: 10, fontWeight: '400' },
  notConnected: { fontSize: 9, fontWeight: '700' },
  giftGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  giftCard: { width: '48%', flexGrow: 1, minWidth: 140, borderWidth: 1, borderRadius: 17, padding: 11, gap: 6 },
  giftArt: { height: 84, borderRadius: 12, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  giftSpark: { position: 'absolute', top: 17, right: 30, width: 4, height: 4, borderRadius: 3 },
  giftName: { fontSize: 11, fontWeight: '700' },
  giftDetail: { fontSize: 9, lineHeight: 13 },
  giftPriceRow: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingTop: 3 },
  giftPrice: { fontSize: 10, fontWeight: '700' },
  vipBanner: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 15, padding: 12 },
  vipBannerTitle: { fontSize: 11, fontWeight: '700', marginBottom: 4 },
  profileHero: { alignItems: 'center', paddingTop: 6, paddingBottom: 3 },
  profileGlow: { width: 134, height: 134, borderRadius: 70, borderWidth: 3, padding: 5, alignItems: 'center', justifyContent: 'center', shadowOpacity: 0.6, shadowRadius: 18, elevation: 7 },
  profilePhoto: { width: 116, height: 116, borderRadius: 60 },
  frameSpark: { position: 'absolute', width: 11, height: 11, borderRadius: 6, right: 7, top: 20, borderWidth: 2, borderColor: '#111525' },
  profileName: { fontSize: 19, fontWeight: '700', marginTop: 14 },
  profileHandle: { fontSize: 11, marginTop: 4 },
  changePhoto: { flexDirection: 'row', gap: 7, alignItems: 'center', borderWidth: 1, borderRadius: 30, paddingHorizontal: 13, paddingVertical: 9, marginTop: 12 },
  changePhotoText: { fontSize: 10, fontWeight: '600' },
  frameIntro: { fontSize: 10, marginTop: -6, marginBottom: 13 },
  frameGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  frameOption: { width: '31%', flexGrow: 1, minWidth: 92, minHeight: 105, borderWidth: 1, borderRadius: 15, padding: 10, alignItems: 'center', justifyContent: 'center', gap: 5 },
  frameIcon: { width: 35, height: 35, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  frameName: { fontSize: 10, fontWeight: '700' },
  frameSubtitle: { fontSize: 8 },
  frameCheck: { position: 'absolute', top: 7, right: 7 },
  vipProfileCard: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 16, padding: 12 },
  vipBadge: { width: 37, height: 37, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  aiHero: { borderRadius: 22, padding: 20, alignItems: 'center', overflow: 'hidden' },
  aiOrb: { width: 62, height: 62, borderRadius: 32, borderWidth: 1, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  aiOrbDot: { position: 'absolute', width: 8, height: 8, borderRadius: 4, top: 7, right: 7 },
  aiTitle: { fontSize: 18, fontWeight: '700', textAlign: 'center' },
  aiSubtitle: { fontSize: 11, lineHeight: 16, textAlign: 'center', marginTop: 7, maxWidth: 260 },
  connectionTag: { flexDirection: 'row', alignItems: 'center', gap: 7, borderWidth: 1, borderRadius: 30, paddingHorizontal: 10, paddingVertical: 6, marginTop: 15 },
  connectionDot: { width: 6, height: 6, borderRadius: 3 },
  connectionText: { fontSize: 9, fontWeight: '600' },
  promptList: { gap: 8, marginTop: -13 },
  promptChip: { minHeight: 44, borderRadius: 14, borderWidth: 1, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  promptText: { fontSize: 11, fontWeight: '500' },
  aiInputWrap: { minHeight: 49, borderWidth: 1, borderRadius: 15, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, gap: 10 },
  aiInput: { flex: 1, paddingVertical: 10, fontSize: 11 },
});
